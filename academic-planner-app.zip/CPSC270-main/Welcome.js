// Welcome.js
import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

export default function Welcome({ navigation }) {
  return (
    <View style={styles.container}>
      <View>
        <Image
          source={require("./toDoIcon.jpg")}
          style={{height: 125, width: 125, borderRadius: 20, position: 'absolute', top: 40, left: 10}}
        />
        <Image
          source={require("./gradesIcon.jpg")}
          style={{height: 125, width: 125, borderRadius: 20, position: 'absolute', top: 40, left: 135}}
        />
        <Image
          source={require("./calendarIcon.jpg")}
          style={{height: 125, width: 125, borderRadius: 20, position: 'absolute', top: 40, left: 260}}
        />
        <Image
          source={require("./studentIcon.jpg")}
          style={{height: 150, width: 150, borderRadius: 20, position: 'absolute', top: 200, left: 125}}
        />
      </View>
      <View style={{ padding: 22, top: 380 }}>
        <Text style={{ fontSize: 54, fontWeight: '800', color: 'white', alignSelf: 'center' }}>Let's get</Text>
        <Text style={{ fontSize: 54, fontWeight: '800', color: 'white', alignSelf: 'center' }}>started</Text>
        <Text style={{ marginTop: 20, fontSize: 18, fontWeight: '500', color: 'white', alignSelf: 'center' }}>Best unreleased student planner App!!</Text>
        <Text style={{ marginTop: 10, fontSize: 15, fontWeight: '300', color: 'white', alignSelf: 'center' }}>Easy planning with: calendar, daily to do's, assignments tracker, and grade calculator</Text>
        <TouchableOpacity style={styles.signup} onPress={() => navigation.navigate("SignUp")}>
          <Text style={{ fontSize: 20, padding: 7 }}>Sign Up</Text>
        </TouchableOpacity>
        <View style={{ flexDirection: 'row', justifyContent: 'center', marginTop: 15 }}>
          <Text style={{ fontSize: 20 }}>Already have an account? </Text>
          <TouchableOpacity style={styles.login} onPress={() => navigation.navigate("Login")}>
            <Text style={{ fontSize: 20, color: 'white', fontWeight: 'bold' }}>Login</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
 
  signup: {
    backgroundColor: '#B7ECE9',
    alignItems: 'center',
    justifyContent: 'center',
    height: 48,
    width: '60%',
    borderRadius: 10,
    alignSelf: 'center',
    marginTop: 30,
  },

    container: {
      flex: 1,
      backgroundColor: '#ADD8E6',
    },
    signup:{
      marginTop:20, 
      backgroundColor:'white', 
      width:'100%', 
      borderRadius:20, 
      height:40,
      alignItems:'center',
      left:10,
    },
  });