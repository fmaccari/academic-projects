import React, { useState, useEffect  } from 'react';
import { StyleSheet, Text, View, TextInput, Image, SafeAreaView, TouchableOpacity,} from 'react-native';

export default function ProfilePics({navigation}) {

    return (
      <SafeAreaView style={styles.container}>
          <View style={{flexDirection:'row'}}>
            <TouchableOpacity onPress={()=>navigation.navigate("Profile", {path: require('./avatar1.jpg')})}>
              <Image source={require("./avatar1.jpg")} style={{height:200, width:200,}}/>
            </TouchableOpacity>
            <TouchableOpacity onPress={()=>navigation.navigate("Profile", {path: require('./avatar3.png')})}>
              <Image source={require("./avatar3.png")} style={{height:160, width:160, top:20,left:15,}}/>
            </TouchableOpacity>
          </View>
          <View style={{flexDirection:'row'}}>
            <TouchableOpacity onPress={()=>navigation.navigate("Profile", {path: require('./avatar2.jpg')})}>
              <Image source={require("./avatar2.jpg")} style={{height:200, width:200,}}/>
            </TouchableOpacity>
            <TouchableOpacity onPress={()=>navigation.navigate("Profile", {path: require('./avatar4.avif')})}>
              <Image source={require("./avatar4.avif")} style={{height:165, width:165, top:15, left:15,}}/>
            </TouchableOpacity>
          </View>
          <View style={{flexDirection:'row'}}>
            <TouchableOpacity onPress={()=>navigation.navigate("Profile", {path: require('./avatar6.jpg')})}>
              <Image source={require("./avatar6.jpg")} style={{height:195, width:195,}}/>
            </TouchableOpacity>
            <TouchableOpacity onPress={()=>navigation.navigate("Profile", {path: require('./avatar5.avif')})}>
              <Image source={require("./avatar5.avif")} style={{height:225, width:225, bottom:15, right:10,}}/>
            </TouchableOpacity>
          </View>
      </SafeAreaView>
    );
  }
  
  const styles = StyleSheet.create({
      container: {
        flex: 1,
        backgroundColor: 'white',
      },
    });