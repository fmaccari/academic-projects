import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet, Text, TouchableOpacity, SafeAreaView } from 'react-native';
import { Ionicons } from "@expo/vector-icons";

export default function Login({ navigation, users }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isPasswordShown, setIsPasswordShown] = useState(false);
  const handleLogin = () => {
    
    const user = users.find(user => user.username === username && user.password === password);
    if (user) {
     
      navigation.navigate('HomeScreen');
    } else {
      alert('Invalid username or password');
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={{ marginHorizontal: 22 }}>
        <View style={{ marginVertical: 22 }}>
          <Text style={{ fontSize: 30 }}>Login into your account</Text>
        </View>
        <View style={{ marginBottom: 12 }}>
          <Text style={{ fontSize: 16, fontWeight: 400, marginVertical: 8 }}>
            Username
          </Text>
          <View style={styles.inputContainer}>
            <TextInput
              placeholder='Enter username'
              style={styles.input}
              value={username}
              onChangeText={setUsername}
            />
          </View>
        </View>

        <View style={{ marginBottom: 12 }}>
          <Text style={{ fontSize: 16, fontWeight: 400, marginVertical: 8 }}>
            Password
          </Text>
          <View style={styles.inputContainer}>
            <TextInput
              placeholder='Enter password'
              secureTextEntry={!isPasswordShown}
              style={styles.input}
              value={password}
              onChangeText={setPassword}
            />
            <TouchableOpacity style={styles.eyeIcon} onPress={() => setIsPasswordShown(!isPasswordShown)}>
              {isPasswordShown ? (
                <Ionicons name="eye-off" size={24} color={'black'} />
              ) : (
                <Ionicons name="eye" size={24} color={'black'} />
              )}
            </TouchableOpacity>
          </View>
          <TouchableOpacity style={styles.signup} onPress={handleLogin}>
            <Text style={{ fontSize: 20, padding: 7 }}>Login</Text>
          </TouchableOpacity>
          <View style={{ flexDirection: 'row', justifyContent: 'center', marginTop: 20 }}>
            <Text style={{ fontSize: 18 }}>Don't have an account? </Text>
            <TouchableOpacity style={styles.login} onPress={() => navigation.navigate("SignUp")}>
              <Text style={{ fontSize: 18, color: '#B7ECE9', fontWeight: 'bold' }}>Register</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    padding: 20,
  },
  inputContainer: {
    height: 48,
    width: '100%',
    borderWidth: 1,
    borderRadius: 8,
    flexDirection: 'row',
    alignItems: 'center',
    paddingLeft: 22,
  },
  input: {
    flex: 1,
    width: '100%',

  },
  eyeIcon: {
    position: 'absolute',
    right: 12,
  },
  signup: {
    marginTop: 20,
    backgroundColor: '#B7ECE9',
    width: '100%',
    borderRadius: 8,
    height: 40,
    alignItems: 'center',
  },
});