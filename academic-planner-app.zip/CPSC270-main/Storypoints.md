As a WHO, I want WHAT so that WHY

As a student, I want to have a calendar to store all my assignmnets and tests due dates, so that I organize my study plan better.
As a student, I want to be able to see my average grade in the class, so that I'm aware of how I'm doing in the course.
As a student, I want to be able to see what grades I should get to reach my grade goal, so that I can improve my overall gpa.
As a student, I want to store my daily todos, so that I can keep track of the tasks for the day.
As a student, I want to see my average for multiple courses, so that it's quicker to track my performance.
As a student, I want to have weekly reminders of my week's assignments and tasks, so that I can plan ahead and better manage my time.
As a student, I want to be able to delete wrong input values, so that my app doesn't give me wrong results.
As a student, I want to see how deep in the course and what percentage of assignments I have left, so that I'm aware how many opportunities I have to accomplish my grade goal.
As a student, I want to see what my progressive overall gpa for that semester is, so that I can see if I want to try to improve it.
As a student, I want to have the app pull out all my assignments and tasks for the class automatically, so that it saves me time.
