import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, ScrollView } from 'react-native';
import { Swipeable } from 'react-native-gesture-handler';
import Icon from 'react-native-vector-icons/Ionicons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Icon2 from 'react-native-vector-icons/FontAwesome';

export default function CourseListScreen({ route, navigation }) {
  const initialCourses = route.params?.courses || [];
  const [courses, setCourses] = useState(initialCourses);
  useEffect(() => {
    
    loadCourseData();
  }, []);
  
  useEffect(() => {
    
    saveCourseData();
  }, [courses]);

  useEffect(() => {
    console.log('Courses Updated:', courses);
  }, [courses]);

  
  
  
  const loadCourseData = async () => {
    try {
      const savedData = await AsyncStorage.getItem('courseData');
      if (savedData !== null) {
        const parsedData = JSON.parse(savedData);
        if (Array.isArray(parsedData)) {
          setCourses(parsedData);
        } else {
          console.error('Saved data is not an array:', parsedData);
        }
      }
    } catch (error) {
      console.error('Error loading course data:', error);
    }
  };
  
  const addCourse = () => {
    navigation.navigate('AddCourse', { courseToEdit: null, onAddCourse: handleAddCourse });
  };
  const editCourse = (course, index) => {
    console.log('Editing Course at Index:', index);  
    navigation.navigate('AddCourse', {
      courseToEdit: course,
      index,  
      onSaveCourse: handleSaveEditedCourse,
      isEditing: true
    });
  };
  
  
  

  const gotoAssignment = (courseName, gradeGoal) => {
    navigation.navigate('AssignmentListScreen', { 
      courseName: courseName,
      gradeGoal: gradeGoal 
    });
  };
  
  const handleAddCourse = (newCourse) => {
    const updatedCourses = [...courses, newCourse];
    setCourses(updatedCourses);
  };


  const handleSaveEditedCourse = (editedCourse, index) => {
    if (typeof index !== 'number') {
      console.error('Invalid index:', index);
      return; 
    }
    setCourses(courses => {
      const updatedCourses = [...courses];
      updatedCourses[index] = editedCourse;
      return updatedCourses;
    });
  };
  
  
  const removeCourse = (index) => {
    const updatedCourses = [...courses];
    updatedCourses.splice(index, 1);
    setCourses(updatedCourses);
  };


  const renderCourse = (course, index) => {
    return (
      <Swipeable key={index} renderRightActions={() => (
        <TouchableOpacity onPress={() => removeCourse(index)} style={styles.deleteButton}>
          <Text style={{ color: 'white' }}>Delete</Text>
        </TouchableOpacity>
      )}>
        <TouchableOpacity style={styles.courseContainer} onPress={() => gotoAssignment(course.name, course.gradeGoal)}>
          <View style={styles.editContainer}>
            <TouchableOpacity style={styles.editButton} onPress={() => editCourse(course, index)}>
              <Text style={{ fontSize: 12 }}>Edit</Text>
            </TouchableOpacity>
          </View>
          <Text style={styles.courseTitle}>{course.name}</Text>
          <View style={styles.courseInfo}>
            <View style={styles.iconInfo}>
              <Icon name="book" size={20} color="black" />
              <Text>{course.credits}</Text>
            </View>
            <View style={styles.iconInfo}>
              <Icon2 name="bell" size={20} color="black" />
              <Text>{course.gradeGoal}</Text>
            </View>
          </View>
        </TouchableOpacity>
      </Swipeable>
    );
  };

  const renderCoursesByTerm = () => {
    const terms = {};
    courses.forEach(course => {
      const termYear = `${course.term} ${course.year}`;
      if (!terms[termYear]) {
        terms[termYear] = [];
      }
      terms[termYear].push(course);
    });

    return Object.entries(terms).map(([termYear, courses], index) => (
      <View key={index}>
        <Text style={styles.subtitle}>{termYear}</Text>
        {courses.map((course, index) => renderCourse(course, index))}
      </View>
    ));
  };
  const saveCourseData = async () => {
    if (Array.isArray(courses)) {
      try {
        await AsyncStorage.setItem('courseData', JSON.stringify(courses));
      } catch (error) {
        console.error('Error saving course data:', error);
      }
    } else {
      console.error('Courses is not an array:', courses);
    }
  };
  

  

  return (
    <View style={styles.screenContainer}>
      <TouchableOpacity onPress={() => navigation.goBack()} style={styles.arrowContainer}>
        <View style={styles.greenCircle}>
          <Icon name={'arrow-back'} size={30} color="white" />
        </View>
      </TouchableOpacity>
      <View style={styles.header}>
        <Text style={styles.title}>Course List</Text>
      </View>

      <ScrollView style={{ flex: 1 }}>
        {renderCoursesByTerm()}
      </ScrollView>
      <TouchableOpacity
  style={styles.addButton}
  onPress={addCourse}
>
  <Icon2 name="plus" size={24} color="black" />
</TouchableOpacity>
    </View>
  );
}
const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    backgroundColor: 'white',
    padding: 20,
  },
  arrowContainer: {
    position: 'absolute',
    top:50,
    left: 20,
    zIndex: 1,
  },
  greenCircle: {
    backgroundColor: '#B7ECE9',
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    marginBottom: 5,
    marginTop:40,
    marginLeft:55,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginLeft: 10,
    left:50,
  },
  subtitle: {
    fontSize: 20,
    marginBottom: 5,
    marginTop: 30,
  
    marginLeft:20,
  },
  courseContainer: {
    backgroundColor: '#e6faff',
    borderRadius: 20,
    padding: 20,
    marginVertical: 10,
    width: '95%',
    alignSelf: 'center',
  },
  deleteButton: {
    backgroundColor: 'red',
    justifyContent: 'center',
    alignItems: 'center',
    width: 100,
    borderRadius: 20,
    marginRight: 10,
  },
  addButton: {
    
      backgroundColor: '#B7ECE9',
      width: 50,
      height: 50,
      borderRadius: 25,
      justifyContent: 'center',
      alignItems: 'center',
      position: 'absolute',
      bottom: 10,
      right: 170,
    
    
  },
  editContainer: {
    position: 'absolute',
    top: 10,
    right: 10,
    zIndex: 1,
  },
  editButton: {
    backgroundColor: 'lightgreen',
    padding: 5,
    borderRadius: 5,
  },
  courseTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  courseInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconInfo: {
    flexDirection: 'row',
    marginRight: 20,
  },
});
