import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createMaterialBottomTabNavigator } from '@react-navigation/material-bottom-tabs';
import Icon from 'react-native-vector-icons/Ionicons';
import HomeScreen from './HomeScreen';
import Schedule from './Schedule';
import CourseListScreen from './Academics';
import NewCourse from './AddCourse';
import AssignmentListScreen from './AssignmentListScreen';
import NewAssignment from './AddAssignment';
import Welcome from './Welcome';
import Login from './Login';
import SignUp from './SignUp';
import ProfilePage from './ProfilePage';
import ProfilePics from './ProfilePics';
import { UserProvider } from './UserContext';
import { LogBox } from 'react-native';

const Tab = createMaterialBottomTabNavigator();

const Stack = createStackNavigator();
LogBox.ignoreAllLogs();

export default function App() {
  const [users, setUsers] = useState([]);

  return (
    <UserProvider>
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Welcome" >
        <Stack.Screen name="Welcome" component={Welcome} options={{ headerShown: false }}/>
        <Stack.Screen name="Login">
          {props => <Login {...props} users={users} />}
        </Stack.Screen>
        <Stack.Screen name="SignUp">
          {props => <SignUp {...props} users={users} setUsers={setUsers} />}
        </Stack.Screen>
        <Stack.Screen name="HomeScreen" component={HomeTabs} options={{ headerShown: false }} >
        </Stack.Screen>
      </Stack.Navigator>
    </NavigationContainer>
    </UserProvider>
  );
}

function HomeTabs({users}) {
  return (
    <Tab.Navigator
      initialRouteName="HomeScreen"
      activeColor="black"
      inactiveColor="black"
      barStyle={{ backgroundColor: '#B7ECE9' }}
    >
      <Tab.Screen
        name="HomeScreen"
        component={HomeScreen}
        options={{
          tabBarIcon: ({ color }) => (
            <Icon name="home" color={color} size={26} />
          ),
        }}
      />
      <Tab.Screen
        name="Academics"
        component={AcademicsStack}
        options={{
          tabBarIcon: ({ color }) => (
            <Icon name="school" color={color} size={26} />
          ),
        }}
      />
      <Tab.Screen
        name="Calendar"
        component={Schedule}
        options={{
          tabBarIcon: ({ color }) => (
            <Icon name="calendar" color={color} size={26} />
          ),
        }}
      />
      <Tab.Screen
        name="Profile"
        component={ProfileStack}
        options={{
          tabBarIcon: ({ color }) => (
            <Icon name="person" color={color} size={26} />
          ),
        }}
      >
      </Tab.Screen>
    </Tab.Navigator>
  );
}

function AcademicsStack(){
  return (
    <Stack.Navigator initialRouteName="Academics">
      <Stack.Screen name="Academics" component={CourseListScreen} options={{ headerShown: false }} />
      <Stack.Screen name="AssignmentListScreen" component={AssignmentListScreen} options={{ headerShown: false }} />
      <Stack.Screen name="AddAssignment" component={NewAssignment}  options={{ headerShown: false }}/>
      <Stack.Screen name="AddCourse" component={NewCourse}  options={{ headerShown: false }}/>
    </Stack.Navigator>
  );
}

function ProfileStack({users}) {
  return (
   
    <NavigationContainer independent={true}>
      <Stack.Navigator initialRouteName='Profile'>
        <Stack.Screen
            name="Profile"
            component={ProfilePage}
            options={{
            headerShown:false
            }}
        >
        </Stack.Screen>
        <Stack.Screen
            name="Pick a Profile Picture"
            component={ProfilePics}
            options={{
            headerShown:true
            }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  
    );
  }