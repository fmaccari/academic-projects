import { calculateGrades } from './gradeCalculations';
import testCases from './testCases.json';

describe('Grade Calculation Tests', () => {
  testCases.forEach(({ description, assignments, gradeGoal, expectedAverage, expectedRequiredGrade }) => {
    test(description, () => {
      const { averageGrade, requiredGrade } = calculateGrades(assignments, gradeGoal);
      expect(averageGrade).toEqual(expectedAverage);
      expect(requiredGrade).toEqual(expectedRequiredGrade);
    });
  });
});
