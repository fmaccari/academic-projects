export function calculateGrades(assignments, gradeGoal) {
    let totalGrade = 0;
    let totalWeight = 0;
    assignments.forEach(assignment => {
      if (assignment.grade !== '' && !isNaN(assignment.grade) && assignment.weight !== '' && !isNaN(assignment.weight)) {
        totalGrade += parseFloat(assignment.grade) * (parseFloat(assignment.weight) / 100);
        totalWeight += parseFloat(assignment.weight);
      }
    });
  
    const averageGrade = totalWeight > 0 ? (totalGrade / (totalWeight / 100)).toFixed(0) : 0;
    
    const remainingWeight = 100 - totalWeight;
    const totalGradeGoal = parseFloat(gradeGoal);
    const remainingGrade = totalGradeGoal - totalGrade;
    const requiredGrade = remainingWeight > 0 ? (remainingGrade / (remainingWeight / 100)).toFixed(0) : 'N/A';
  
    return {
      averageGrade: parseFloat(averageGrade),
      requiredGrade: remainingWeight > 0 ? parseFloat(requiredGrade) : 'N/A'
    };
  }
  