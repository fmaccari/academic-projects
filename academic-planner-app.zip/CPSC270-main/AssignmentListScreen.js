import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, TextInput, ScrollView } from 'react-native';
import { Swipeable } from 'react-native-gesture-handler';
import Icon from 'react-native-vector-icons/Ionicons';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function AssignmentListScreen({ route, navigation }) {
  const [assignments, setAssignments] = useState([]);
  const [gradeGoal, setGradeGoal] = useState('');
  const [averageGrade, setAverageGrade] = useState(0);
  const [requiredGrade, setRequiredGrade] = useState(0);
  useEffect(() => {
    const courseName = route.params?.courseName;
    if (courseName) {
      fetchAssignments(courseName);
      setGradeGoal(route.params.gradeGoal);
    }
  }, [route.params?.courseName, route.params?.gradeGoal]);

  const fetchAssignments = async (courseName) => {
    try {
      const savedData = await AsyncStorage.getItem(courseName);
      if (savedData) {
        const parsedData = JSON.parse(savedData);
        setAssignments(parsedData);
      } else {
        setAssignments([]);
      }
    } catch (error) {
      console.error('Error loading assignments data:', error);
    }
  };

  const saveAssignmentsData = async (courseName) => {
    try {
      await AsyncStorage.setItem(courseName, JSON.stringify(assignments));
    } catch (error) {
      console.error('Error saving assignments data:', error);
    }
  };

  useEffect(() => {
    const courseName = route.params?.courseName;
    if (courseName) {
      saveAssignmentsData(courseName);
    }
    calculateAverageGrade();
  }, [assignments]);

  useEffect(() => {
    if (assignments.length > 0) {
      calculateAverageGrade();
    }
  }, [assignments]);
  
  const calculateAverageGrade = () => {
    let totalGrade = 0;
    let totalWeight = 0;
    assignments.forEach(assignment => {
      if (assignment.grade !== '' && !isNaN(assignment.grade) && assignment.weight !== '' && !isNaN(assignment.weight)) {
        totalGrade += parseFloat(assignment.grade) * (parseFloat(assignment.weight) / 100);
        totalWeight += parseFloat(assignment.weight);
      }
    });
  
    const averageGrade = totalWeight > 0 ? (totalGrade / (totalWeight / 100)).toFixed(0) : 0;
    setAverageGrade(parseFloat(averageGrade));
  
    const remainingWeight = 100 - totalWeight;
    const totalGradeGoal = parseFloat(gradeGoal);
    const remainingGrade = totalGradeGoal - totalGrade;
    const requiredGrade = remainingWeight > 0 ? (remainingGrade / (remainingWeight / 100)).toFixed(0) : 'N/A'; // Show 'N/A' or a message if no more weight is available
  
    setRequiredGrade(remainingWeight > 0 ? parseFloat(requiredGrade) : 'N/A');
  };
  
  const handleAddAssignment = (newAssignment) => {
    const updatedAssignments = [...assignments, newAssignment];
    setAssignments(updatedAssignments);
  };

  const handleEditAssignment = (editedAssignment, index) => {
    const updatedAssignments = [...assignments];
    updatedAssignments[index] = { ...updatedAssignments[index], ...editedAssignment };
    setAssignments(updatedAssignments);
  };

  const removeAssignment = (index) => {
    const updatedAssignments = [...assignments];
    updatedAssignments.splice(index, 1);
    setAssignments(updatedAssignments);
  };

  const formatDate = (date) => new Date(date).toLocaleDateString('en-US');

  const renderAssignment = (assignment, index) => {
    const gradeNeeded = assignment.grade ? null : requiredGrade;

    
  return (
    <Swipeable
      key={index}
      renderRightActions={() => (
        <TouchableOpacity onPress={() => removeAssignment(index)} style={styles.deleteButton}>
          <Text style={{ color: 'white' }}>Delete</Text>
        </TouchableOpacity>
      )}
    >
      <TouchableOpacity onPress={() => navigation.navigate('AddAssignment', {
        assignmentToEdit: assignment,
        onEditAssignment: (edit) => handleEditAssignment(edit, index)
      })}>
        <View style={styles.assignmentContainer}>
          <Text style={styles.assignmentName}>{assignment.name}</Text>
          <View style={styles.assignmentDetails}>
            <View style={styles.assignmentDetail}>
              <Icon name="barbell" size={24} color="black" />
              <Text>{assignment.weight}%</Text>
            </View>
            <View style={styles.assignmentDetail}>
              <Icon name="calendar" size={24} color="black" />
              <Text>{formatDate(assignment.dueDate)}</Text>
            </View>
         
            <View style={styles.assignmentDetail}>
              <View style={[styles.gradeCircle, { backgroundColor: assignment.grade !== '' && !isNaN(assignment.grade) ? '#B7ECE9' : 'red' }]}>                
                <Text style={styles.gradeText}>{assignment.grade !== '' && !isNaN(assignment.grade) ? assignment.grade :   requiredGrade}</Text>
                
                </View>
                </View>
                </View>
        </View>
      </TouchableOpacity>
    </Swipeable>
  );
};

return (
  <View style={styles.container}>
  <Text style={styles.header}>Assignments for</Text>
  <Text style={{fontSize: 28, color: 'black',fontWeight:'bold', bottom:10,}}> {route.params?.courseName}</Text>
  <TouchableOpacity onPress={() => navigation.goBack()} style={styles.arrowContainer}>
      <View style={styles.greenCircle}>
        <Icon name={'arrow-back'} size={30} color="white" />
      </View>
  </TouchableOpacity>
  <View style={styles.circleContainer}>
    <View style={styles.circle}>
      <Text style={styles.grade}>{averageGrade}</Text>
      <Text style={{fontSize:15}}>Average Grade</Text>
    </View>
    <View style={styles.circle2}>
      <Text style={styles.grade}>{gradeGoal}</Text>
      <Text style={{fontSize:15, alignContent:'center'}}>Goal Grade</Text>
    </View>
  </View>
    <ScrollView>
      {assignments.map(renderAssignment)}
    </ScrollView>
    <TouchableOpacity style={styles.addButton} onPress={() => navigation.navigate('AddAssignment', { onAddAssignment: handleAddAssignment })}>
    <Text style={{ color: 'black', justifyContent:'center', fontSize:40, fontWeight:'bold'}}>+</Text>
    </TouchableOpacity>
  </View>
);
}

const styles = StyleSheet.create({
container: {
  flex: 1,
  backgroundColor: 'white',
  alignItems: 'center',
  justifyContent: 'center',
},
header: {
  fontSize: 28,
  color: 'black', 
  fontWeight:'bold',
  marginBottom: 20,
  marginTop: 60, 
},
gradeContainer: {
  flexDirection: 'row',
  justifyContent: 'space-around',
  padding: 10,
  backgroundColor: '#ddd'
},
assignmentContainer: {
  backgroundColor: '#e6faff',
  borderRadius: 20,
  padding: 20,
  marginVertical: 10,
  width: '95%', 
  flexDirection: 'column',
  position: 'relative',
},
circle: {
  width: 100,
  height: 100,
  borderRadius: 50,
  backgroundColor: '#B7ECE9',
  justifyContent: 'center',
  alignItems: 'center',
  position: 'relative',
  top: 40,
  right: 80,
},
circle2: {
  width: 100,
  height: 100,
  borderRadius: 50,
  backgroundColor: '#B7ECE9',
  justifyContent: 'center',
  alignItems: 'center',
  position: 'relative',
  top: -60,
  left: 80,
},
assignmentName: {
  fontSize: 18,
  fontWeight: 'bold'
},
assignmentDetails: {
  flexDirection: 'row',
  justifyContent: 'space-between',
  marginBottom: 10, 
},
assignmentDetail: {
  flexDirection: 'row',
  alignItems: 'center',
  marginRight: 20, 
},
gradeNeeded: {
  fontSize: 16,
  color: 'red'
},
grade:{
  fontSize: 35,

},
gradeCircle: {
  width: 50,
  height: 50,
  borderRadius: 25,
  justifyContent: 'center',
  alignItems: 'center',
  
  flexDirection: 'row',
},
deleteButton: {
  backgroundColor: 'red',
  justifyContent: 'center',
  alignItems: 'center',
  width: 100,
  borderRadius: 20,
  marginRight: 10,
},
addButton: {
  backgroundColor: '#B7ECE9',
  width: 50,
  height: 50,
  borderRadius: 25,
  justifyContent: 'center',
  alignItems: 'center',
  position: 'absolute',
  bottom: 10,
  right: 170,
},
gradeText:{
  flexDirection:'column',
},
inputWeight: {
  marginLeft: 10,
  width: 40, 
},
arrowContainer: {
  position: 'absolute',
  top:50,
  left: 20,
  zIndex: 1,
},
greenCircle: {
  backgroundColor: '#B7ECE9',
  width: 50,
  height: 50,
  borderRadius: 25,
  justifyContent: 'center',
  alignItems: 'center',
},
});