import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity, ScrollView, SafeAreaView } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Icon from 'react-native-vector-icons/Ionicons';


export default function NewCourse({ route, navigation }) {
  const { courseToEdit, index, onAddCourse, onSaveCourse, isEditing } = route.params || { courseToEdit: null, onAddCourse: null, index: -1, onSaveCourse: null, isEditing: false };
  const [name, setName] = useState(courseToEdit ? courseToEdit.name : '');
  const [credits, setCredits] = useState(courseToEdit ? courseToEdit.credits : '');
  const [gradeGoal, setGradeGoal] = useState(courseToEdit ? courseToEdit.gradeGoal : '');
  const [term, setTerm] = useState(courseToEdit ? courseToEdit.term : '');
  const [year, setYear] = useState(courseToEdit ? courseToEdit.year : '');


useEffect(() => {
  console.log('Received index:', index); 
}, []);

  useEffect(() => {
    if (courseToEdit) {
      setName(courseToEdit.name);
      setCredits(courseToEdit.credits);
      setGradeGoal(courseToEdit.gradeGoal);
      setTerm(courseToEdit.term);
      setYear(courseToEdit.year);
    }
  }, [courseToEdit]);

  
  const saveData = () => {
    const newCourse = { name, credits, gradeGoal, term, year };
    console.log('Saving Data:', newCourse, index);
    if (isEditing) {
      if (onSaveCourse) {
        console.log('Calling onSaveCourse');
        onSaveCourse(newCourse, index);
      }
    } else {
      if (onAddCourse) {
        console.log('Calling onAddCourse');
        onAddCourse(newCourse);
      }
    }
    navigation.goBack();
  };
  
  
  

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        <View style={{ flex: 1 }}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.arrowContainer}>
            <View style={styles.greenCircle}>
              <Icon name={'arrow-back'} size={30} color="white" />
            </View>
          </TouchableOpacity>
          <Text style={{ top: '5%', textAlign: 'center', fontSize: 30 }}>Add Course</Text>
          <View style={{ backgroundColor: '#e6faff', top: '15%', width: '90%', alignSelf: 'center', borderTopLeftRadius: 20, borderTopRightRadius: 20, borderBottomLeftRadius: 20, borderBottomRightRadius: 20, }}>
            <InputWithIcon title="Name" iconName="list" placeholder="Enter name" value={name} onChangeText={setName} />
            <InputWithIcon title="Credits" iconName="star" placeholder="Enter credits" value={credits} onChangeText={setCredits} keyboardType="numeric" />
            <InputWithIcon title="Goal Grade" iconName="star" placeholder="Enter goal grade" value={gradeGoal} onChangeText={setGradeGoal} keyboardType="numeric" />
            <InputWithIcon title="Term" iconName="calendar" placeholder="Enter school term" value={term} onChangeText={setTerm} />
            <InputWithIcon title="Year" iconName="calendar" placeholder="Enter year" value={year} onChangeText={setYear} keyboardType="numeric" />
          </View>
          <TouchableOpacity style={styles.button} onPress={saveData}><Text style={{ fontSize: 18, textAlign: 'center' }}>Submit Data</Text></TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const InputWithIcon = ({ title, iconName, placeholder, value, onChangeText, keyboardType = "default" }) => {
  return (
    <View style={styles.inputContainer}>
      <View style={styles.iconContainer}>
        <View style={styles.circle}>
          <Icon name={iconName} size={28} color="black" />
        </View>
      </View>
      <View style={styles.nameContainer}>
        <View style={styles.square}>
          <Text>{title}</Text>
        </View>
      </View>
      <View style={styles.input}>
        <TextInput
          style={styles.textInput}
          placeholder={placeholder}
          value={value}
          onChangeText={onChangeText}
          keyboardType={keyboardType}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  inputContainer: {
        flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 10,
    borderRadius:40,
  },
  iconContainer: {
    width: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  circle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#B7ECE9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  nameContainer: {
    marginLeft: 10,
    justifyContent: 'center',
    borderRadius:40,
  },
  square: {
    width: 80,
    height: 40,
    backgroundColor: 'lightgray',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius:40,
  },
  input: {
    marginLeft: 30, 
    borderRadius:40,
  },
  textInput: {
    borderWidth: 1,
    borderColor: 'gray',
    borderRadius: 5,
    padding: 10,
    fontSize: 18,
    borderRadius:40,
  },
  button: {
    backgroundColor: '#B7ECE9',
    alignSelf: 'center',
    top: '16%',
    width: '90%',
    height: '7%',
    borderRadius: 20,
    padding: 15,
  },
  arrowContainer: {
    position: 'absolute',
    top:30,
    left: 20,
    zIndex: 1,
  },
  greenCircle: {
    backgroundColor: '#B7ECE9',
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
