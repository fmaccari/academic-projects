# CPSC270
Participants:
Daniela Valverde
Federico Maccari
*IDEA:
Calendar for storing tasks and achieving grading goals.
including(Calendar, grades, averages, goals, assignments, store important file)
*PROBLEM:
TIME SAVING
OPTIONS 
TIME MANAGEMENT AND GOALS ACHIVEMENT
DAILY ORGANIZATION
SCHOOL WORK

