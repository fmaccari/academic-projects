import React, { useEffect} from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity, Image, SafeAreaView, Pressable,} from 'react-native';
import { Avatar} from 'react-native-paper';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useUser } from './UserContext';

export default function ProfilePage({navigation, route}){

  const { currentUser } = useUser();
    let imageShown= undefined;

    if(route.params !== undefined){
      imageShown=route.params.path;
    }else{
      imageShown=require('./addProfileIMG.png')
    }
    
    useEffect(()=>{
        const loadImage=async ()=>{
          try{
            const storedImage=await AsyncStorage.getItem('imageShown');
            if(storedImage){
              imageShown=(JSON.parse(storedImage));
            }
          }catch(error){
            alert("Couldn't load image, error in the parse");
          }
        };
        loadImage();
      },[route.params?.path]);
    
      useEffect(()=>{
        const saveImage=async()=>{
          try{
            await AsyncStorage.setItem('imageShown', JSON.stringify(imageShown));
          }catch(error){
            alert("Couldn't save image, error in the stringify");
          }
        };
        saveImage();
      }),[imageShown];
    
  return (

      <SafeAreaView style={styles.screenContainer}>
          <View style={styles.image}>
              <TouchableOpacity onPress={()=>navigation.navigate("Pick a Profile Picture")}>
                  <Avatar.Image
                  style={{backgroundColor:'#c7c8c9',}}
                  source={imageShown}
                  size={250}
                  />
              </TouchableOpacity>
          </View>
              <View style={{top:'10%'}}>
                  <View style={{backgroundColor:'#f0fcff', width:'90%', height:'25%',alignSelf:'center',borderRadius: 20, borderWidth:1,justifyContent:'center'}}>
                      <View style={{flexDirection:'row', alignSelf:'left', left:20}}>
                      <Text style={{ fontSize: 20 }}>Username: {currentUser?.username}</Text>
                      </View>
                  </View>
                  <View style={{backgroundColor:'#f0fcff', top: 10,width:'90%', height:'25%',alignSelf:'center',borderRadius: 20, borderWidth:1,justifyContent:'center'}}>
                      <View style={{flexDirection:'row', alignSelf:'left', left:20}}>
                      <Text style={{ fontSize: 20 }}>Password: {currentUser?.password}</Text> 
                      </View>
                  </View>
              </View>
             
          
      </SafeAreaView>
  );  
}


const styles = StyleSheet.create({
    screenContainer: {
        flex: 1,
        backgroundColor:'white',
    },
    image:{
        alignItems: 'center',
        paddingTop:30,
    },
    title:{
        paddingTop:10,
        fontSize:30,
        alignSelf:'center',
    },
    input: {
        marginTop:10,
        textAlign: 'center',
        fontSize: 18,
        padding:11,
    },
    });