// NewCourse.js
import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, SafeAreaView, TouchableOpacity, ScrollView } from 'react-native';

export default function NewCourse({ navigation }) {
  const [name, setName] = useState('');
  const [credits, setCredits] = useState(0);
  const [gradeGoal, setGradeGoal] = useState(0);
  const [term, setTerm] = useState('');
  const [year, setYear] = useState(0);

  const saveData = async () => {
    console.warn(name, credits, gradeGoal, term, year);
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <Text style={{ top: "5%", textAlign: 'center', fontSize: 30 }}>Add Course</Text>
        <View style={{ backgroundColor: '#e6faff', top: '15%', width: '90%', alignSelf: 'center', borderTopLeftRadius: 20, borderTopRightRadius: 20, borderBottomLeftRadius: 20, borderBottomRightRadius: 20, }}>
          {/* Your input components */}
        </View>
        <TouchableOpacity style={styles.button} onPress={saveData}><Text style={{ fontSize: 18, textAlign: 'center', }}>Submit Data</Text></TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ADD8E6',
  },
  input: {
    marginTop:10,
    textAlign: 'center',
    fontSize: 18,
    padding:11,
    //width: 200,
    //left: 180,
  },
  title:{
    fontSize:18,
    left:'3%',
    padding:10,
  },
  button:{
    backgroundColor:'white',
    alignSelf:'center',
    top:'16%',
    width:'90%', 
    height:'9%', 
    borderRadius:20, 
    padding:15,
  },
});
