import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, Button } from 'react-native';
import { Calendar } from 'react-native-calendars';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useIsFocused } from '@react-navigation/native';



const Schedule = () => {
    const [markedDates, setMarkedDates] = useState({});
    const [upcomingAssignments, setUpcomingAssignments] = useState([]);
    const isFocused = useIsFocused(); 

    useEffect(() => {
        if (isFocused) {
            fetchAllAssignments();
        }
    }, [isFocused]);  

    const fetchAllAssignments = async () => {
        try {
            const keys = await AsyncStorage.getAllKeys();
            const stores = await AsyncStorage.multiGet(keys);
            let allAssignments = [];
            let dates = {};
            let localUpcomingAssignments = [];

            stores.forEach((result) => {
                let key = result[0];
                let value;
                try {
                    value = JSON.parse(result[1]);
                } catch (error) {
                    console.error("Failed to parse data for key:", key, error);
                    return; 
                }
                if (Array.isArray(value)) {
                    allAssignments.push(...value.map(item => ({ ...item, courseName: key })));
                }
            });

            allAssignments.forEach(assignment => {
                if (assignment.dueDate && assignment.name) {
                    const normalizedDate = new Date(assignment.dueDate);
                    if (!isNaN(normalizedDate)) {
                        const dueDateStr = normalizedDate.toISOString().split('T')[0];
                        if (!dates[dueDateStr]) {
                            dates[dueDateStr] = { dots: [] };
                        }

                        if (assignment.grade) {
                            dates[dueDateStr].dots.push({ color: 'green', key: 'complete' });
                        } else {
                            dates[dueDateStr].dots.push({ color: 'red', key: 'incomplete' });
                        }

                        const today = new Date();
                        today.setHours(0, 0, 0, 0); 
                        const nextWeek = new Date(today);
                        nextWeek.setDate(today.getDate() + 7);
                        if (normalizedDate >= today && normalizedDate <= nextWeek && !assignment.grade) {
                            localUpcomingAssignments.push({
                                ...assignment,
                                dueDateFormatted: dueDateStr
                            });
                        }
                    }
                }
            });

            setMarkedDates(dates);
            setUpcomingAssignments(localUpcomingAssignments.sort((a, b) => new Date(a.dueDateFormatted) - new Date(b.dueDateFormatted)));
        } catch (error) {
            console.error('Failed to load the assignments:', error);
        }
    };

    return (
        <View style={styles.container}>
            <Text style={styles.title}> Schedule</Text>
            <View style={styles.calendarcontainer}>
            <Calendar
                markingType={'multi-dot'}
                markedDates={markedDates}
            />
            </View>
            <View style={styles.listcontainer}>
            <Text style={styles.subHeader}>Upcoming Assignments</Text>
            
            <ScrollView>
                {upcomingAssignments.map((assignment, index) => (
                    <View key={index} style={styles.assignmentItem}>
                        <Text>{`${assignment.name} - ${assignment.courseName}`}</Text>
                        <Text>{assignment.dueDateFormatted}</Text>
                    </View>
                ))}
            </ScrollView>
            
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    
    container: {
        flex: 1,
        padding: 10,
        backgroundColor: '#fff',
    },
    title:{
        fontSize:30,
        top:40,
        left:30,
        fontWeight: 'bold',
    },
    calendarcontainer:{
        position:'relative',
        top:50,
    },
    subHeader: {
        fontSize: 18,
        fontWeight: 'bold',
        marginBottom: 10,
    },
    assignmentItem: {
        padding: 10,
        borderBottomWidth: 1,
        borderBottomColor: '#ccc',
        marginBottom: 5,
    },
    refreshButton: {
        backgroundColor: 'blue',
        color: 'white',
        padding: 10,
        marginVertical: 10,
    },
    listcontainer:{
        position:'relative',
        top:50,
    },
});

export default Schedule;
