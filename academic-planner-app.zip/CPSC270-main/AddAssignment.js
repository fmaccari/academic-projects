import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity, ScrollView, SafeAreaView } from 'react-native';
import DatePicker from "@dietime/react-native-date-picker";
import Icon from 'react-native-vector-icons/Ionicons';
import SimpleLineIcons from 'react-native-vector-icons/SimpleLineIcons';

export default function NewAssignment({ route, navigation }) {
  const { assignmentToEdit, onAddAssignment, onEditAssignment, isEditing } = route.params || { assignmentToEdit: null, onAddAssignment: null, onEditAssignment: null, isEditing: false };

  const [name, setName] = useState(assignmentToEdit ? assignmentToEdit.name : '');
  const [weight, setWeight] = useState(assignmentToEdit ? assignmentToEdit.weight : '');
  const [grade, setGrade] = useState(assignmentToEdit ? assignmentToEdit.grade : '');
  const [dueDate, setDueDate] = useState(assignmentToEdit ? new Date(assignmentToEdit.dueDate) : '');

  
  useEffect(() => {
    if (assignmentToEdit) {
      setName(assignmentToEdit.name);
      setWeight(assignmentToEdit.weight);
      setGrade(assignmentToEdit.grade);
      setDueDate(new Date(assignmentToEdit.dueDate));
    }
  }, [assignmentToEdit]);

  const saveData = () => {
    const newAssignment = { name, weight, grade, dueDate: dueDate.toString() };
    if (isEditing) {
      if (onEditAssignment) {
        onEditAssignment({ ...assignmentToEdit, ...newAssignment });
      }
    } else {
      if (onAddAssignment) {
        onAddAssignment(newAssignment);
      }
    }
    navigation.goBack();
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        <View style={{ flex: 1 }}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.arrowContainer}>
            <View style={styles.greenCircle}>
              <Icon name={'arrow-back'} size={30} color="white" />
            </View>
          </TouchableOpacity>
          <Text style={{ top: '5%', textAlign: 'center', fontSize: 30 }}>Add Assignment</Text>
          <View style={{ backgroundColor: '#e6faff', top: '15%', width: '90%', alignSelf: 'center', borderTopLeftRadius: 20, borderTopRightRadius: 20, borderBottomLeftRadius: 20, borderBottomRightRadius: 20, }}>
            <InputWithIcon title="Name" iconName="list" placeholder="Enter name" value={name} onChangeText={setName} />
            <InputWithIcon title="Weight" iconName="barbell" placeholder="Enter weight" value={weight} onChangeText={setWeight} keyboardType="numeric" />
            <InputWithIcon title="Grade" iconName="star" placeholder="Enter grade" value={grade} onChangeText={setGrade} keyboardType="numeric" />
            <InputWithDatePicker title="Due Date" iconName="calendar" value={dueDate} onChange={setDueDate} />
          </View>
          <TouchableOpacity style={styles.button} onPress={saveData}><Text style={{ fontSize: 18, textAlign: 'center' }}>Submit Data</Text></TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const InputWithIcon = ({ title, iconName, placeholder, value, onChangeText, keyboardType = "default" }) => {
  return (
    <View style={styles.inputContainer}>
      <View style={styles.iconContainer}>
        <View style={styles.circle}>
          <Icon name={iconName} size={28} color="black" />
        </View>
      </View>
      <View style={styles.nameContainer}>
        <View style={styles.square}>
          <Text>{title}</Text>
        </View>
      </View>
      <View style={styles.input}>
        <TextInput
          style={styles.textInput}
          placeholder={placeholder}
          value={value}
          onChangeText={onChangeText}
          keyboardType={keyboardType}
        />
      </View>
    </View>
  );
}

const InputWithDatePicker = ({ title, iconName, value, onChange }) => {
  return (
    <View style={styles.inputContainer}>
      <View style={styles.iconContainer}>
        <View style={styles.circle}>
          <Icon name={iconName} size={28} color="black" />
        </View>
      </View>
      <View style={styles.nameContainer}>
        <View style={styles.square}>
          <Text>{title}</Text>
        </View>
      </View>
      <View style={styles.input}>
        <DatePicker
          value={value}
          onChange={onChange}
          format="mm-dd-yyyy"
          mode="date"
          height={120}
          style={{ width: 100, marginTop: 10 }}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 10,
  },
  iconContainer: {
    width: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  circle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#B7ECE9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  nameContainer: {
    marginLeft: 10,
    justifyContent: 'center',
  },
  square: {
    width: 80,
    height: 40,
    backgroundColor: 'lightgray',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius:40,
  },
  input: {
    marginLeft: 50,
    flex: 1,
  },
  textInput: {
    borderWidth: 1,
    borderColor: 'gray',
    borderRadius: 5,
    padding: 10,
    fontSize: 18,
  },
  title: {
    fontSize: 18,
    left: '3%',
    padding: 10,
  },
  button: {
    backgroundColor: '#B7ECE9',
    alignSelf: 'center',
    top: '16%',
    width: '90%',
    height: '7%',
    borderRadius: 20,
    padding: 15,
  },
  arrowContainer: {
    position: 'absolute',
    top:30,
    left: 20,
    zIndex: 1,
  },
  greenCircle: {
    backgroundColor: '#B7ECE9',
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
