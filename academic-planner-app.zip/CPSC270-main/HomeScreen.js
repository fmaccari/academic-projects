import * as React from 'react';
import { Text, View, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/Ionicons';
import SimpleLineIcons from 'react-native-vector-icons/SimpleLineIcons';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function HomeScreen() {
  const navigation = useNavigation();
  const [todayCount, setTodayCount] = React.useState(0);
  const [weekCount, setWeekCount] = React.useState(0);

  React.useEffect(() => {
    fetchAssignments().then(({ today, thisWeek }) => {
      setTodayCount(today);
      setWeekCount(thisWeek);
    });
  }, []);

  const fetchAssignments = async () => {
    const keys = await AsyncStorage.getAllKeys();
    const stores = await AsyncStorage.multiGet(keys);
    let today = 0;
    let thisWeek = 0;
    const now = new Date();
    const endOfWeek = new Date(now);
    endOfWeek.setDate(now.getDate() + (7 - now.getDay())); 

    stores.forEach((result) => {
        let key = result[0];
        let value;
        try {
            value = JSON.parse(result[1]);
        } catch (e) {
            console.error("Error parsing data for key:", key, e);
            return; 
        }

        if (Array.isArray(value)) {
            value.forEach(assignment => {
                const dueDate = new Date(assignment.dueDate);
                if (dueDate.toDateString() === now.toDateString()) {
                    today++;
                }
                if (dueDate > now && dueDate <= endOfWeek) {
                    thisWeek++;
                }
            });
        } else {
            console.log("Stored data is not an array for key:", key);
        }
    });

    return { today, thisWeek };
};


  const handleContainerPress = (screenName) => {
    navigation.navigate(screenName);
  };

  return (
    <View style={styles.screenContainer}>
      <Text style={styles.message}>Hello Student!</Text>
      <View style={styles.container}>
        <TouchableOpacity onPress={() => handleContainerPress('Calendar')}>
          <View style={[styles.box, styles.firstBox]}>
            <View style={styles.circle}>
              <SimpleLineIcons name={'pin'} size={28} color="black" />
            </View>
            <Text style={styles.boxText}>Today ({todayCount})</Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => handleContainerPress('Calendar')}>
          <View style={styles.box}>
            <View style={styles.circle}>
              <Icon name={'list'} size={28} color="black" />
            </View>
            <Text style={styles.boxText}>This week ({weekCount})</Text>
          </View>
        </TouchableOpacity>
        <Image
          style={styles.tinyLogo}
          source={require('./tiger.png')}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    padding: 20,
  },
  message: {
    fontSize: 30,
    fontWeight: 'bold',
    marginTop: 45,
    marginBottom: 40,
  },
  tinyLogo:{
   
    alignItems: 'center',
    height:200,
    width:200,
    left:-160,
    bottom:-410,
    
  },
  container: {
    flexDirection: 'row', 
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  box: {
    width: 160,
    height: 100,
    borderRadius: 20,
    backgroundColor: '#B7ECE9',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  firstBox: {
    marginRight: 30,
  },
  circle: {
    width: 60,
    height: 60,
    borderRadius: 40,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
    alignSelf: 'left',
    marginLeft: 10,
  },
  boxText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
});
