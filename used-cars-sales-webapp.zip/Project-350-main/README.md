# Project-350
This is Federico Maccari, Daniela Valverde, Sara Hailemariam CPSC-350 final project

Used Car Selling

Short Description:

The Used Car Selling System is a web-based application designed to help individuals buy and sell used cars with ease. The application is specifically tailored for sellers who are looking to sell their used cars or search for available used cars based on specific criteria. The system will also allow sellers to research different car brands and models, providing information such as ratings, reviews, and available cars.

This platform is aimed at used car sellers, buyers, and researchers who want a simple way to buy and sell cars without hassle. It also focuses on providing sellers with ratings and reviews to help them make informed purchasing decisions.


Key Features (User Actions):

Sell Your Car:

sellers can submit details about the used cars they want to sell (make, model, year, price, condition, mileage, and photos).

*sellers can upload images of their car.

Search for Cars: sellers can browse available cars using filters such as:

- Car make (e.g., Toyota, Honda)

- Model

- Year

- Price range

- Mileage

- Rating

We can Sort options by price, rating, year, and mileage.

We can also have: Detailed car view page showing full information about the selected car (including photos).

Research Cars: sellers can select a car brand and model to research.

It will display information such as:

- Average rating for that car model

- User reviews

- List of available cars for that make and model.

Rating and Reviews:

- sellers can leave ratings (1–5 stars) and write reviews for cars they have interacted with.

- View average ratings for each car model on the research and listing pages.


We can have user Registration and Login: sellers can create an account to keep track of the cars they’re selling or the ones they are interested in purchasing.


Do we want the application to be accessible on mobile, tablet, and desktop?


The website we were looking at https://www.truecar.com/
