import tkinter as tk
from tkinter import messagebox
import psycopg2
import hashlib
from flask import Flask, jsonify, request
from flask_cors import CORS
import threading
import os 
from dotenv import load_dotenv

app = Flask(__name__)
CORS(app)

load_dotenv()  
app.secret_key = os.getenv("AUTH_SECRET")
DATABASE_URL = os.getenv("POSTGRES_URL")

login_status = {}

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def setup_database():
    try:
        conn = psycopg2.connect(DATABASE_URL)
        cursor = conn.cursor()
        
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS sellers (
                id SERIAL PRIMARY KEY, 
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL
            );
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS brands (
                brand_id SERIAL PRIMARY KEY,
                brand_name TEXT NOT NULL
            );
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS colors (
                color_id SERIAL PRIMARY KEY,
                color_name TEXT NOT NULL
            );
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS fuels (
                fuel_id SERIAL PRIMARY KEY,
                fuel_name TEXT NOT NULL
            );
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS states (
                state_id SERIAL PRIMARY KEY,
                state_name TEXT NOT NULL
            );
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS cars (
                car_id SERIAL PRIMARY KEY,
                brand_id INTEGER REFERENCES brands(brand_id) ON DELETE CASCADE,
                car_model TEXT NOT NULL,
                year INTEGER NOT NULL,
                mileage INTEGER NOT NULL,
                condition INTEGER NOT NULL,
                price INTEGER NOT NULL,
                state_id INTEGER REFERENCES states(state_id) ON DELETE CASCADE,
                fuel_id INTEGER REFERENCES fuels(fuel_id) ON DELETE CASCADE,
                exterior_color INTEGER REFERENCES colors(color_id) ON DELETE CASCADE,
                interior_color INTEGER REFERENCES colors(color_id) ON DELETE CASCADE,
                seller_id INTEGER REFERENCES sellers(id) ON DELETE CASCADE,
                image_url TEXT
            );
        ''')

        
        constraints = [
            ("brands", "brand_name", "unique_brand_name"),
            ("states", "state_name", "unique_state_name"),
            ("fuels", "fuel_name", "unique_fuel_name"),
            ("colors", "color_name", "unique_color_name"),
        ]

        for table, column, constraint_name in constraints:
            cursor.execute(f'''
                DO $$
                BEGIN
                    IF NOT EXISTS (
                        SELECT 1
                        FROM pg_constraint
                        WHERE conname = '{constraint_name}'
                    ) THEN
                        ALTER TABLE {table} ADD CONSTRAINT {constraint_name} UNIQUE ({column});
                    END IF;
                END $$;
            ''')

        conn.commit()
        conn.close()
    except Exception as e:
        print(f"Database setup error: {e}")


def update_login_status(seller_id, user_name):
    login_status[seller_id] = {"logged_in": True, "user_name": user_name}

def tkinter_login_form():
    def sign_in():
        email = email_entry.get()
        password = hash_password(password_entry.get())

        if not email or not password:
            messagebox.showerror("Error", "Email and password are required.")
            return

        try:
            conn = psycopg2.connect(DATABASE_URL)
            cursor = conn.cursor()
            cursor.execute('SELECT id, first_name FROM sellers WHERE email = %s AND password = %s', (email, password))
            user = cursor.fetchone()
            conn.close()

            if user:
                seller_id, user_name = user[0], user[1]
                update_login_status(seller_id, user_name)
                messagebox.showinfo("Welcome", f"Welcome, {user_name}!")
                root.destroy()  
            else:
                messagebox.showerror("Login Failed", "Invalid email or password.")
        except Exception as e:
            messagebox.showerror("Database Error", f"Could not fetch data: {e}")

    def open_signup():
        root.destroy()
        tkinter_signup_form()

    def open_forgot_password():
        root.destroy()
        tkinter_forgot_password_form()

    root = tk.Tk()
    root.title("Login")
    root.geometry("400x300")

    tk.Label(root, text="Email:").grid(row=0, column=0, padx=10, pady=10, sticky="e")
    email_entry = tk.Entry(root)
    email_entry.grid(row=0, column=1, padx=10, pady=10)

    tk.Label(root, text="Password:").grid(row=1, column=0, padx=10, pady=10, sticky="e")
    password_entry = tk.Entry(root, show="*")
    password_entry.grid(row=1, column=1, padx=10, pady=10)

    tk.Button(root, text="Sign In", command=sign_in).grid(row=2, column=0, columnspan=2, pady=10)
    tk.Button(root, text="Sign Up", command=open_signup).grid(row=3, column=0, columnspan=2, pady=5)
    tk.Button(root, text="Forgot Password", command=open_forgot_password).grid(row=4, column=0, columnspan=2, pady=5)

    root.mainloop()

def tkinter_signup_form():
    def create_account():
        first_name = first_name_entry.get()
        last_name = last_name_entry.get()
        email = email_entry_signup.get()
        password = hash_password(password_entry_signup.get())

        if not first_name or not last_name or not email or not password:
            messagebox.showerror("Error", "All fields are required.")
            return

        try:
            conn = psycopg2.connect(DATABASE_URL)
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO sellers (first_name, last_name, email, password)
                VALUES (%s, %s, %s, %s)
            ''', (first_name, last_name, email, password))
            conn.commit()
            conn.close()
            messagebox.showinfo("Success", "Account created successfully!")
            signup_window.destroy()
            tkinter_login_form()
        except psycopg2.IntegrityError:
            messagebox.showerror("Error", "Email already exists.")
        except Exception as e:
            messagebox.showerror("Database Error", f"Could not save data: {e}")

    signup_window = tk.Tk()
    signup_window.title("Sign Up")
    signup_window.geometry("400x300")

    tk.Label(signup_window, text="First Name:").grid(row=0, column=0, padx=10, pady=10, sticky="e")
    first_name_entry = tk.Entry(signup_window)
    first_name_entry.grid(row=0, column=1, padx=10, pady=10)

    tk.Label(signup_window, text="Last Name:").grid(row=1, column=0, padx=10, pady=10, sticky="e")
    last_name_entry = tk.Entry(signup_window)
    last_name_entry.grid(row=1, column=1, padx=10, pady=10)

    tk.Label(signup_window, text="Email:").grid(row=2, column=0, padx=10, pady=10, sticky="e")
    email_entry_signup = tk.Entry(signup_window)
    email_entry_signup.grid(row=2, column=1, padx=10, pady=10)

    tk.Label(signup_window, text="Password:").grid(row=3, column=0, padx=10, pady=10, sticky="e")
    password_entry_signup = tk.Entry(signup_window, show="*")
    password_entry_signup.grid(row=3, column=1, padx=10, pady=10)

    tk.Button(signup_window, text="Create Account", command=create_account).grid(row=4, column=0, columnspan=2, pady=10)

    signup_window.mainloop()

def tkinter_forgot_password_form():
    def reset_password():
        email = email_forgot.get()
        new_password = hash_password(password_forgot.get())

        if not email or not new_password:
            messagebox.showerror("Error", "All fields are required.")
            return

        try:
            conn = psycopg2.connect(DATABASE_URL)
            cursor = conn.cursor()
            cursor.execute('UPDATE sellers SET password = %s WHERE email = %s', (new_password, email))
            if cursor.rowcount == 0:
                messagebox.showerror("Error", "Email not found.")
            else:
                conn.commit()
                messagebox.showinfo("Success", "Password updated successfully!")
                forgot_window.destroy()
                tkinter_login_form()
            conn.close()
        except Exception as e:
            messagebox.showerror("Database Error", f"Could not update password: {e}")

    forgot_window = tk.Tk()
    forgot_window.title("Forgot Password")
    forgot_window.geometry("400x200")

    tk.Label(forgot_window, text="Enter your email:").grid(row=0, column=0, padx=10, pady=10, sticky="e")
    email_forgot = tk.Entry(forgot_window)
    email_forgot.grid(row=0, column=1, padx=10, pady=10)

    tk.Label(forgot_window, text="Enter new password:").grid(row=1, column=0, padx=10, pady=10, sticky="e")
    password_forgot = tk.Entry(forgot_window, show="*")
    password_forgot.grid(row=1, column=1, padx=10, pady=10)

    tk.Button(forgot_window, text="Reset Password", command=reset_password).grid(row=2, column=0, columnspan=2, pady=10)

    forgot_window.mainloop()

def tkinter_car_submission_form(seller_id):
    
    us_states = [
        "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA", "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA",
        "ME", "MD", "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY", "NC", "ND", "OH", "OK",
        "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY"
    ]
    fuel_types = ["Gasoline", "Diesel", "Electric", "Hybrid", "Other"]
    condition_scale = [1, 2, 3, 4, 5]

    def submit_car():
        brand = car_brand_entry.get()
        model = car_model_entry.get()
        year = car_year_entry.get()
        mileage = car_mileage_entry.get()
        condition = condition_var.get()
        price = car_price_entry.get()
        state = state_var.get()
        fuel = fuel_var.get()
        exterior_color = exterior_color_entry.get()
        interior_color = interior_color_entry.get()

        if not brand or not model or not year or not mileage or not condition or not price or not state or not fuel or not exterior_color or not interior_color:
            messagebox.showerror("Error", "All fields are required.")
            return

        try:
            conn = psycopg2.connect(DATABASE_URL)
            cursor = conn.cursor()

           
            cursor.execute("INSERT INTO brands (brand_name) VALUES (%s) ON CONFLICT (brand_name) DO NOTHING RETURNING brand_id", (brand,))
            brand_id = cursor.fetchone()
            if not brand_id:
                cursor.execute("SELECT brand_id FROM brands WHERE brand_name = %s", (brand,))
                brand_id = cursor.fetchone()[0]
            else:
                brand_id = brand_id[0]

            
            cursor.execute("INSERT INTO states (state_name) VALUES (%s) ON CONFLICT (state_name) DO NOTHING RETURNING state_id", (state,))
            state_id = cursor.fetchone()
            if not state_id:
                cursor.execute("SELECT state_id FROM states WHERE state_name = %s", (state,))
                state_id = cursor.fetchone()[0]
            else:
                state_id = state_id[0]

           
            cursor.execute("INSERT INTO fuels (fuel_name) VALUES (%s) ON CONFLICT (fuel_name) DO NOTHING RETURNING fuel_id", (fuel,))
            fuel_id = cursor.fetchone()
            if not fuel_id:
                cursor.execute("SELECT fuel_id FROM fuels WHERE fuel_name = %s", (fuel,))
                fuel_id = cursor.fetchone()[0]
            else:
                fuel_id = fuel_id[0]

            cursor.execute("INSERT INTO colors (color_name) VALUES (%s) ON CONFLICT (color_name) DO NOTHING RETURNING color_id", (exterior_color,))
            exterior_color_id = cursor.fetchone()
            if not exterior_color_id:
                cursor.execute("SELECT color_id FROM colors WHERE color_name = %s", (exterior_color,))
                exterior_color_id = cursor.fetchone()[0]
            else:
                exterior_color_id = exterior_color_id[0]

            
            cursor.execute("INSERT INTO colors (color_name) VALUES (%s) ON CONFLICT (color_name) DO NOTHING RETURNING color_id", (interior_color,))
            interior_color_id = cursor.fetchone()
            if not interior_color_id:
                cursor.execute("SELECT color_id FROM colors WHERE color_name = %s", (interior_color,))
                interior_color_id = cursor.fetchone()[0]
            else:
                interior_color_id = interior_color_id[0]

            
            cursor.execute('''
                INSERT INTO cars (brand_id, car_model, year, mileage, condition, price, state_id, fuel_id, exterior_color, interior_color, seller_id)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            ''', (brand_id, model, year, mileage, condition, price, state_id, fuel_id, exterior_color_id, interior_color_id, seller_id))

            conn.commit()
            conn.close()
            messagebox.showinfo("Success", "Car submitted successfully!")
            car_form.destroy()
        except Exception as e:
            messagebox.showerror("Database Error", f"Could not save car data: {e}")

    car_form = tk.Tk()
    car_form.title("Submit Car")
    car_form.geometry("400x700")

    tk.Label(car_form, text="Brand:").grid(row=0, column=0, padx=10, pady=10, sticky="e")
    car_brand_entry = tk.Entry(car_form)
    car_brand_entry.grid(row=0, column=1, padx=10, pady=10)

    tk.Label(car_form, text="Model:").grid(row=1, column=0, padx=10, pady=10, sticky="e")
    car_model_entry = tk.Entry(car_form)
    car_model_entry.grid(row=1, column=1, padx=10, pady=10)

    tk.Label(car_form, text="Year:").grid(row=2, column=0, padx=10, pady=10, sticky="e")
    car_year_entry = tk.Entry(car_form)
    car_year_entry.grid(row=2, column=1, padx=10, pady=10)

    tk.Label(car_form, text="Mileage:").grid(row=3, column=0, padx=10, pady=10, sticky="e")
    car_mileage_entry = tk.Entry(car_form)
    car_mileage_entry.grid(row=3, column=1, padx=10, pady=10)

    tk.Label(car_form, text="Condition (1-5):").grid(row=4, column=0, padx=10, pady=10, sticky="e")
    condition_var = tk.IntVar(car_form)
    condition_dropdown = tk.OptionMenu(car_form, condition_var, *condition_scale)
    condition_dropdown.grid(row=4, column=1, padx=10, pady=10)

    tk.Label(car_form, text="Price:").grid(row=5, column=0, padx=10, pady=10, sticky="e")
    car_price_entry = tk.Entry(car_form)
    car_price_entry.grid(row=5, column=1, padx=10, pady=10)

    tk.Label(car_form, text="State:").grid(row=6, column=0, padx=10, pady=10, sticky="e")
    state_var = tk.StringVar(car_form)
    state_dropdown = tk.OptionMenu(car_form, state_var, *us_states)
    state_dropdown.grid(row=6, column=1, padx=10, pady=10)

    tk.Label(car_form, text="Fuel:").grid(row=7, column=0, padx=10, pady=10, sticky="e")
    fuel_var = tk.StringVar(car_form)
    fuel_dropdown = tk.OptionMenu(car_form, fuel_var, *fuel_types)
    fuel_dropdown.grid(row=7, column=1, padx=10, pady=10)

    tk.Label(car_form, text="Exterior Color:").grid(row=8, column=0, padx=10, pady=10, sticky="e")
    exterior_color_entry = tk.Entry(car_form)
    exterior_color_entry.grid(row=8, column=1, padx=10, pady=10)

    tk.Label(car_form, text="Interior Color:").grid(row=9, column=0, padx=10, pady=10, sticky="e")
    interior_color_entry = tk.Entry(car_form)
    interior_color_entry.grid(row=9, column=1, padx=10, pady=10)

    tk.Button(car_form, text="Submit", command=submit_car).grid(row=10, column=0, columnspan=2, pady=10)

    car_form.mainloop()

@app.route('/launch-edit-car', methods=['POST'])
def launch_edit_car():
    try:
        car_id = request.json.get("car_id")
        seller_id = request.json.get("seller_id")

        if not car_id or not str(car_id).isdigit():
            return jsonify({"error": "Invalid car_id"}), 400
        if not seller_id or not str(seller_id).isdigit():
            return jsonify({"error": "Invalid seller_id"}), 400

        conn = psycopg2.connect(DATABASE_URL)
        cursor = conn.cursor()
        cursor.execute('''
            SELECT
                cars.car_id,
                brands.brand_name,
                cars.car_model,
                cars.year,
                cars.mileage,
                cars.condition,
                cars.price,
                states.state_name,
                fuels.fuel_name,
                ext_colors.color_name AS exterior_color,
                int_colors.color_name AS interior_color
            FROM cars
            LEFT JOIN brands ON cars.brand_id = brands.brand_id
            LEFT JOIN states ON cars.state_id = states.state_id
            LEFT JOIN fuels ON cars.fuel_id = fuels.fuel_id
            LEFT JOIN colors AS ext_colors ON cars.exterior_color = ext_colors.color_id
            LEFT JOIN colors AS int_colors ON cars.interior_color = int_colors.color_id
            WHERE cars.car_id = %s AND cars.seller_id = %s
        ''', (int(car_id), int(seller_id)))
        car = cursor.fetchone()
        conn.close()

        if not car:
            return jsonify({"error": "Car not found"}), 404

        
        threading.Thread(target=tkinter_edit_car_form, args=(car,)).start()
        return jsonify({"message": "Edit car form launched!"}), 200

    except Exception as e:
        return jsonify({"error": f"Server error: {str(e)}"}), 500

def tkinter_edit_car_form(car):
    """
    Tkinter form for editing a car.
    """
    car_id, brand_name, model, year, mileage, condition, price, state_name, fuel_name, exterior_color, interior_color = car

    
    us_states = [
        "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA", "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA",
        "ME", "MD", "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY", "NC", "ND", "OH", "OK",
        "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY"
    ]
    fuel_types = ["Gasoline", "Diesel", "Electric", "Hybrid", "Other"]
    condition_scale = [1, 2, 3, 4, 5]

    def update_car():
        """
        Save the updated car details to the database.
        """
        new_brand = car_brand_edit_entry.get()
        new_model = car_model_edit_entry.get()
        new_year = car_year_edit_entry.get()
        new_mileage = car_mileage_edit_entry.get()
        new_condition = condition_var.get()
        new_price = car_price_edit_entry.get()
        new_state = state_var.get()
        new_fuel = fuel_var.get()
        new_exterior_color = exterior_color_edit_entry.get()
        new_interior_color = interior_color_edit_entry.get()

        if not new_brand or not new_model or not new_year or not new_mileage or not new_condition or not new_price or not new_state or not new_fuel or not new_exterior_color or not new_interior_color:
            messagebox.showerror("Error", "All fields are required.")
            return

        try:
            conn = psycopg2.connect(DATABASE_URL)
            cursor = conn.cursor()

            
            cursor.execute("INSERT INTO brands (brand_name) VALUES (%s) ON CONFLICT (brand_name) DO NOTHING RETURNING brand_id", (new_brand,))
            brand_id = cursor.fetchone()
            if not brand_id:
                cursor.execute("SELECT brand_id FROM brands WHERE brand_name = %s", (new_brand,))
                brand_id = cursor.fetchone()[0]
            else:
                brand_id = brand_id[0]

            
            cursor.execute("INSERT INTO states (state_name) VALUES (%s) ON CONFLICT (state_name) DO NOTHING RETURNING state_id", (new_state,))
            state_id = cursor.fetchone()
            if not state_id:
                cursor.execute("SELECT state_id FROM states WHERE state_name = %s", (new_state,))
                state_id = cursor.fetchone()[0]
            else:
                state_id = state_id[0]

            
            cursor.execute("INSERT INTO fuels (fuel_name) VALUES (%s) ON CONFLICT (fuel_name) DO NOTHING RETURNING fuel_id", (new_fuel,))
            fuel_id = cursor.fetchone()
            if not fuel_id:
                cursor.execute("SELECT fuel_id FROM fuels WHERE fuel_name = %s", (new_fuel,))
                fuel_id = cursor.fetchone()[0]
            else:
                fuel_id = fuel_id[0]

            
            cursor.execute("INSERT INTO colors (color_name) VALUES (%s) ON CONFLICT (color_name) DO NOTHING RETURNING color_id", (new_exterior_color,))
            exterior_color_id = cursor.fetchone()
            if not exterior_color_id:
                cursor.execute("SELECT color_id FROM colors WHERE color_name = %s", (new_exterior_color,))
                exterior_color_id = cursor.fetchone()[0]
            else:
                exterior_color_id = exterior_color_id[0]

            
            cursor.execute("INSERT INTO colors (color_name) VALUES (%s) ON CONFLICT (color_name) DO NOTHING RETURNING color_id", (new_interior_color,))
            interior_color_id = cursor.fetchone()
            if not interior_color_id:
                cursor.execute("SELECT color_id FROM colors WHERE color_name = %s", (new_interior_color,))
                interior_color_id = cursor.fetchone()[0]
            else:
                interior_color_id = interior_color_id[0]

            
            cursor.execute('''
                UPDATE cars
                SET brand_id = %s, car_model = %s, year = %s, mileage = %s, condition = %s, price = %s,
                    state_id = %s, fuel_id = %s, exterior_color = %s, interior_color = %s
                WHERE car_id = %s
            ''', (brand_id, new_model, new_year, new_mileage, new_condition, new_price,
                state_id, fuel_id, exterior_color_id, interior_color_id, car_id))

            conn.commit()
            conn.close()
            messagebox.showinfo("Success", "Car updated successfully!")
            edit_window.destroy()
        except Exception as e:
            messagebox.showerror("Database Error", f"Could not update car: {e}")

    
    edit_window = tk.Tk()
    edit_window.title("Edit Car")
    edit_window.geometry("400x700")

    tk.Label(edit_window, text="Brand:").grid(row=0, column=0, padx=10, pady=10, sticky="e")
    car_brand_edit_entry = tk.Entry(edit_window)
    car_brand_edit_entry.insert(0, brand_name)
    car_brand_edit_entry.grid(row=0, column=1, padx=10, pady=10)

    tk.Label(edit_window, text="Model:").grid(row=1, column=0, padx=10, pady=10, sticky="e")
    car_model_edit_entry = tk.Entry(edit_window)
    car_model_edit_entry.insert(0, model)
    car_model_edit_entry.grid(row=1, column=1, padx=10, pady=10)

    tk.Label(edit_window, text="Year:").grid(row=2, column=0, padx=10, pady=10, sticky="e")
    car_year_edit_entry = tk.Entry(edit_window)
    car_year_edit_entry.insert(0, year)
    car_year_edit_entry.grid(row=2, column=1, padx=10, pady=10)

    tk.Label(edit_window, text="Mileage:").grid(row=3, column=0, padx=10, pady=10, sticky="e")
    car_mileage_edit_entry = tk.Entry(edit_window)
    car_mileage_edit_entry.insert(0, mileage)
    car_mileage_edit_entry.grid(row=3, column=1, padx=10, pady=10)

    tk.Label(edit_window, text="Condition (1-5):").grid(row=4, column=0, padx=10, pady=10, sticky="e")
    condition_var = tk.IntVar(edit_window)
    condition_var.set(condition)
    condition_dropdown = tk.OptionMenu(edit_window, condition_var, *condition_scale)
    condition_dropdown.grid(row=4, column=1, padx=10, pady=10)

    tk.Label(edit_window, text="Price:").grid(row=5, column=0, padx=10, pady=10, sticky="e")
    car_price_edit_entry = tk.Entry(edit_window)
    car_price_edit_entry.insert(0, price)
    car_price_edit_entry.grid(row=5, column=1, padx=10, pady=10)

    tk.Label(edit_window, text="State:").grid(row=6, column=0, padx=10, pady=10, sticky="e")
    state_var = tk.StringVar(edit_window)
    state_var.set(state_name)
    state_dropdown = tk.OptionMenu(edit_window, state_var, *us_states)
    state_dropdown.grid(row=6, column=1, padx=10, pady=10)

    tk.Label(edit_window, text="Fuel:").grid(row=7, column=0, padx=10, pady=10, sticky="e")
    fuel_var = tk.StringVar(edit_window)
    fuel_var.set(fuel_name)
    fuel_dropdown = tk.OptionMenu(edit_window, fuel_var, *fuel_types)
    fuel_dropdown.grid(row=7, column=1, padx=10, pady=10)

    tk.Label(edit_window, text="Exterior Color:").grid(row=8, column=0, padx=10, pady=10, sticky="e")
    exterior_color_edit_entry = tk.Entry(edit_window)
    exterior_color_edit_entry.insert(0, exterior_color)
    exterior_color_edit_entry.grid(row=8, column=1, padx=10, pady=10)

    tk.Label(edit_window, text="Interior Color:").grid(row=9, column=0, padx=10, pady=10, sticky="e")
    interior_color_edit_entry = tk.Entry(edit_window)
    interior_color_edit_entry.insert(0, interior_color)
    interior_color_edit_entry.grid(row=9, column=1, padx=10, pady=10)

    tk.Button(edit_window, text="Save Changes", command=update_car).grid(row=10, column=0, columnspan=2, pady=10)

    edit_window.mainloop()


@app.route('/launch-car-form', methods=['POST'])
def launch_car_form():
    try:
        seller_id = int(request.json.get("seller_id", 0))  
        if seller_id not in login_status or not login_status[seller_id]["logged_in"]:
            return jsonify({"error": "Unauthorized"}), 401

        app.logger.info(f"Launching car form for seller_id: {seller_id}")
        
        
        threading.Thread(target=tkinter_car_submission_form, args=(seller_id,)).start()
        return jsonify({"message": "Car submission form launched!"}), 200
    except Exception as e:
        app.logger.error(f"Error launching car form: {str(e)}")
        return jsonify({"error": f"Server error: {str(e)}"}), 500
        

@app.route('/launch-login', methods=['GET'])
def launch_login():
    threading.Thread(target=tkinter_login_form).start()
    return jsonify({"message": "Tkinter login form launched!"}), 200


@app.route('/check-login', methods=['GET'])
def check_login():
    try:
        seller_id = request.args.get("seller_id")
        for id, status in login_status.items():
            if status["logged_in"] and (not seller_id or int(seller_id) == id):
                return jsonify({"logged_in": True, "seller_id": id, "user_name": status["user_name"]})
        return jsonify({"logged_in": False}), 401
    except Exception as e:
        app.logger.error(f"Error in /check-login: {str(e)}")
        return jsonify({"logged_in": False, "error": str(e)}), 500


@app.route('/update-car-image', methods=['POST'])
def update_car_image():
    try:
        car_id = request.json.get("car_id")
        image_url = request.json.get("image_url")

        if not car_id or not str(car_id).isdigit():
            return jsonify({"error": "Invalid car_id"}), 400
        if not image_url or not isinstance(image_url, str):
            return jsonify({"error": "Invalid image_url"}), 400

        conn = psycopg2.connect(DATABASE_URL)
        cursor = conn.cursor()

        
        cursor.execute('UPDATE cars SET image_url = %s WHERE car_id = %s', (image_url, car_id))
        if cursor.rowcount == 0:
            conn.close()
            return jsonify({"error": "Car not found"}), 404

        conn.commit()
        conn.close()

        return jsonify({"message": "Car image updated successfully!"}), 200
    except Exception as e:
        app.logger.error(f"Error in /update-car-image: {str(e)}")
        return jsonify({"error": f"Server error: {str(e)}"}), 500


@app.route('/profile', methods=['GET'])
def profile():
    try:
        seller_id = int(request.args.get("seller_id", 0))
        if seller_id not in login_status or not login_status[seller_id]["logged_in"]:
            return jsonify({"error": "Unauthorized"}), 401

        conn = psycopg2.connect(DATABASE_URL)
        cursor = conn.cursor()

        
        cursor.execute('''
            SELECT
                c.car_id,
                b.brand_name,
                c.car_model,
                c.mileage,
                c.year,
                c.condition,
                c.price,
                s.state_name,
                f.fuel_name,
                ext_colors.color_name AS exterior_color,
                int_colors.color_name AS interior_color,
                c.image_url
            FROM cars c
            LEFT JOIN brands b ON c.brand_id = b.brand_id
            LEFT JOIN states s ON c.state_id = s.state_id
            LEFT JOIN fuels f ON c.fuel_id = f.fuel_id
            LEFT JOIN colors ext_colors ON c.exterior_color = ext_colors.color_id
            LEFT JOIN colors int_colors ON c.interior_color = int_colors.color_id
            WHERE c.seller_id = %s
        ''', (seller_id,))
        cars = cursor.fetchall()
        conn.close()

        return jsonify({"user_name": login_status[seller_id]["user_name"], "cars": cars})
    except Exception as e:
        app.logger.error(f"Error in /profile: {str(e)}")
        return jsonify({"error": f"Server error: {str(e)}"}), 500


@app.route('/remove-car', methods=['DELETE'])
def remove_car():
    try:
        car_id = request.json.get("car_id")
        seller_id = request.json.get("seller_id")
        
        if not car_id or not str(car_id).isdigit():
            return jsonify({"error": "Invalid car_id"}), 400
        if not seller_id or not str(seller_id).isdigit():
            return jsonify({"error": "Invalid seller_id"}), 400

        seller_id = int(seller_id)
        car_id = int(car_id)

        if seller_id not in login_status or not login_status[seller_id]["logged_in"]:
            return jsonify({"error": "Unauthorized"}), 401

        conn = psycopg2.connect(DATABASE_URL)
        cursor = conn.cursor()

    
        cursor.execute("SELECT brand_id FROM cars WHERE car_id = %s", (car_id,))
        brand_row = cursor.fetchone()
        if not brand_row:
            conn.close()
            return jsonify({"error": "Car not found"}), 404
        brand_id = brand_row[0]

      
        cursor.execute("DELETE FROM cars WHERE car_id = %s AND seller_id = %s", (car_id, seller_id))
        if cursor.rowcount == 0:
            conn.close()
            return jsonify({"error": "Car not found or not authorized"}), 404

        cursor.execute("SELECT COUNT(*) FROM cars WHERE brand_id = %s", (brand_id,))
        car_count = cursor.fetchone()[0]
        if car_count == 0:
            cursor.execute("DELETE FROM brands WHERE brand_id = %s", (brand_id,))
        
        conn.commit()
        conn.close()
        return jsonify({"message": "Car and orphaned brand removed successfully!" if car_count == 0 else "Car removed successfully!"}), 200

    except Exception as e:
        app.logger.error(f"Error in /remove-car: {str(e)}")
        return jsonify({"error": f"Server error: {str(e)}"}), 500


    
    
@app.route('/logout', methods=['POST'])
def logout():
    try:
        seller_id = request.json.get("seller_id")
        if not seller_id or not str(seller_id).isdigit():
            return jsonify({"error": "Invalid seller_id"}), 400

       
        if int(seller_id) in login_status:
            del login_status[int(seller_id)]
            app.logger.info(f"User {seller_id} logged out successfully.")

        return jsonify({"message": "Logged out successfully!"}), 200
    except Exception as e:
        app.logger.error(f"Error in /logout: {str(e)}")
        return jsonify({"error": f"Server error: {str(e)}"}), 500


if __name__ == "__main__":
    setup_database()
    app.run(debug=True)
