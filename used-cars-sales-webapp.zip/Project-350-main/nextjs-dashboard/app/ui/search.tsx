'use client';

import { MagnifyingGlassIcon } from '@heroicons/react/24/outline';
import { useState } from 'react';
import { useRouter } from 'next/navigation'; // Used to navigate programmatically

export default function Search({ placeholder }: { placeholder: string }) {
  const [searchQuery, setSearchQuery] = useState('');
  const router = useRouter();

  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(event.target.value);
  };

  const handleButtonClick = () => {
    // Navigate to /buyCar with query parameter 'searchQuery'
    router.push(`/buyCar?searchQuery=${searchQuery}`);
  };

  return (
    <div className="relative flex w-full max-w-xl">
      <label htmlFor="search" className="sr-only">
        Search
      </label>
      <input
        id="search"
        type="text"
        className="peer block w-full rounded-full border border-gray-200 py-[15px] px-4 pl-12 text-md outline-none placeholder:text-gray-500 text-center focus:border-gray-500 focus:ring-2 focus:ring-gray-300"
        placeholder={placeholder}
        value={searchQuery}
        onChange={handleInputChange} // Update state on input change
      />
      <MagnifyingGlassIcon className="absolute left-5 top-1/2 h-[18px] w-[18px] -translate-y-1/2 text-gray-500 peer-focus:text-gray-900" />
      
      {/* Button that triggers navigation with searchQuery */}
      <button
        onClick={handleButtonClick}
        className="absolute right-3 top-1/2 -translate-y-1/2 h-9 w-9 rounded-full bg-blue-500 text-white flex items-center justify-center hover:bg-blue-600 focus:outline-none text-3xl"
      >
        ↑
      </button>
    </div>
  );
}
