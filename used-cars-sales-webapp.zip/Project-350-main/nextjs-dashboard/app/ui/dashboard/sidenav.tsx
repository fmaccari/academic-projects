import { ReactNode } from 'react';

interface NavProps {
  children: ReactNode;
}

export default function Nav({ children }: NavProps) {
  return (
    <div className="flex items-center justify-between py-4 px-6 text-sm font-medium text-lg">
    {}
      <img 
        src="/logow.png" 
        alt="Logo" 
        className="w-33 h-auto" 
      />
      <nav>
        <ul className="flex space-x-5">
          {children}
        </ul>
      </nav>
    </div>
  );
}