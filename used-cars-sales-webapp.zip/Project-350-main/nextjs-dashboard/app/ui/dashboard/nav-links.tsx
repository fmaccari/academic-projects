import Link from 'next/link';

const links = [
  { name: 'Home', href: '/' },
  { name: 'Buy', href: '/buyCar' },
  { name: 'Sell', href: '/profile' },
  { name: 'Compare Cars', href: '/compareCars' },
  {name: 'Sign In', href: '/login'},
];

export default function NavLinks() {
  return (
    <>
      {links.map((link) => (
     <Link key={link.name} href={link.href} className="flex h-[40px] grow items-center justify-center gap-2 rounded-md p-4 text-sm font-medium hover:bg-cyan-500 text-slate-50 md:flex-none md:justify-center md:p-2 md:px-4">
     <p className="md:block">{link.name}</p>
   </Link>
   
      ))}
    </>
  );
}
