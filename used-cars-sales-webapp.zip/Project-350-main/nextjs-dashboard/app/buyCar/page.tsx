import Pagination from '@/app/ui/invoices/pagination';
import Search from '@/app/ui/search';
import Table from '@/app/ui/invoices/table';
import { fetchCarBrands, fetchCarFuels, fetchFilteredCars, fetchCarPages } from '@/app/lib/data';
import { Metadata } from 'next';
import clsx from 'clsx';
import Filters from './filters';
import { Button } from '../ui/button';
import { Suspense } from 'react';
import { InvoicesTableSkeleton } from '@/app/ui/skeletons';
import CarsTable from './carsTable';
//import { useSearchParams } from 'next/navigation';
 
export const metadata: Metadata = {
  title: 'Buy a car',
};

export default async function Page({
    searchParams,
  }: {
    searchParams?: {
      query?: string;
      queryMiles?: string;
      queryBrand?:string;
      queryFuel?:string;
      page?: string;
      searchQuery?:string;
    };
  }) {
    const searchQuery = (await searchParams)?.searchQuery || '';
    //console.log("searchQUery:",searchQuery);
    const query = (await searchParams)?.query || '';
    const queryMiles = (await searchParams)?.queryMiles || '';
    const queryBrand=(await searchParams)?.queryBrand || '';
    const queryFuel=(await searchParams)?.queryFuel || '';
    const currentPage = Number((await searchParams)?.page) || 1; 
    //console.log("main Page, brand: ",queryBrand);

  const totalPages = await fetchCarPages(query, queryMiles,queryBrand, queryFuel);
  const brands= await fetchCarBrands();
  const fuels=await fetchCarFuels();
  return (
    <main className="bg-gray-100 min-h-screen px-4">
      
      <div className="fixed top-20 left-5 w-70 bg-gray-100 text-black p-4 shadow-lg rounded-md">
        <Filters placeholderMax="Max price" placeholderMiles='Max amount of miles' carBrands={brands} fuelTypes={fuels}/>
      </div>
  
      <div className="ml-72 w-[70%] bg-gray-100 text-black p-4 shadow-lg rounded-md flex justify-center">
        <CarsTable queryMax={query} queryMiles={queryMiles} queryBrand={queryBrand} currentPage={currentPage} searchQuery={searchQuery} queryFuel={queryFuel}/>
      </div>
  
      
      <div className="flex items-center justify-center mt-8 bg-gray-100">
        <Pagination totalPages={totalPages} />
      </div>
    </main>
  );
  
  }