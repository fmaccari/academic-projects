'use client';
import { useSearchParams, usePathname, useRouter } from 'next/navigation';
import { useDebouncedCallback } from 'use-debounce';
import { brands } from '@/app/lib/definitions';
import Link from 'next/link';
import { fuels } from '@/app/lib/definitions';
import { useState } from 'react';

export default function Filters({
  placeholderMax,
  placeholderMiles,
  carBrands,
  fuelTypes,
}: {
  placeholderMax: string;
  placeholderMiles: string;
  carBrands: brands[];
  fuelTypes: fuels[];
}) {
  const searchParams = useSearchParams();
  const pathname = usePathname();
  const { replace } = useRouter();

  // Track the input values using state
  const [queryMax, setQueryMax] = useState(searchParams.get('query') || '');
  const [queryMiles, setQueryMiles] = useState(searchParams.get('queryMiles') || '');

  // Debounced callbacks to handle input changes
  const handleSearchMax = useDebouncedCallback((termMax) => {
    const params = new URLSearchParams(searchParams);
    params.set('page', '1');
    if (termMax) params.set('query', termMax);
    else params.delete('query');
    replace(`${pathname}?${params.toString()}`);
  }, 300);

  const handleSearchMiles = useDebouncedCallback((term) => {
    const params = new URLSearchParams(searchParams);
    params.set('page', '1');
    if (term) params.set('queryMiles', term);
    else params.delete('queryMiles');
    replace(`${pathname}?${params.toString()}`);
  }, 300);

  const handleBrandChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedBrand = e.target.value;
    const params = new URLSearchParams(searchParams);
    params.set('page', '1');
    if (selectedBrand) params.set('queryBrand', selectedBrand);
    else params.delete('queryBrand');
    replace(`${pathname}?${params.toString()}`);
  };

  const queryBrand = searchParams.get('queryBrand') || '';

  const handleFuelChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedFuel = e.target.value;
    const params = new URLSearchParams(searchParams);
    params.set('page', '1');
    if (selectedFuel) params.set('queryFuel', selectedFuel);
    else params.delete('queryFuel');
    replace(`${pathname}?${params.toString()}`);
  };

  const queryFuel = searchParams.get('queryFuel') || '';

  // Function to clear filters and input values when Cancel link is clicked
  const handleClearFilters = () => {
    const params = new URLSearchParams();
    params.set('page', '1'); // Reset the page to 1
    replace(`${pathname}?${params.toString()}`); // Update the URL with no filters

    // Reset the input field values to empty
    setQueryMax('');
    setQueryMiles('');
  };

  return (
    <div className="flex flex-col items-center gap-3 rounded-md border">
      <input
        type="number"
        placeholder={placeholderMax}
        onChange={(e) => {
          setQueryMax(e.target.value); // Update the state with the new value
          handleSearchMax(e.target.value); // Debounced search
        }}
        value={queryMax} // Bind the value to the state
        className="peer block border py-[10px] pl-16 text-sm"
      />
      <input
        type="number"
        placeholder={placeholderMiles}
        onChange={(e) => {
          setQueryMiles(e.target.value); // Update the state with the new value
          handleSearchMiles(e.target.value); // Debounced search
        }}
        value={queryMiles} // Bind the value to the state
        className="peer block border py-[10px] pl-16 text-sm"
      />
      <select
        id="brand_id"
        name="brand_id"
        onChange={handleBrandChange}
        value={queryBrand}
        className="peer block w-full rounded-md border py-2 text-sm"
      >
        <option value="">Select a car brand</option>
        {carBrands.map((brand) => (
          <option key={brand.brand_id} value={brand.brand_name}>
            {brand.brand_name}
          </option>
        ))}
      </select>
      <select
        id="fuel_id"
        name="fuel_id"
        onChange={handleFuelChange}
        value={queryFuel}
        className="peer block w-full rounded-md border py-2 text-sm"
      >
        <option value="">Select a fuel type</option>
        {fuelTypes.map((fuel) => (
          <option key={fuel.fuel_id} value={fuel.fuel_name}>
            {fuel.fuel_name}
          </option>
        ))}
      </select>
      {/* Cancel link that resets filters and input values */}
      <Link
        href={`${pathname}?`}
        onClick={handleClearFilters} // This will reset the filters and input values
        className="flex h-9 items-center rounded-lg bg-blue-100 px-4 text-sm font-medium text-gray-600 transition-colors hover:bg-gray-200"
      >
        Clear All
      </Link>
    </div>
  );
}
