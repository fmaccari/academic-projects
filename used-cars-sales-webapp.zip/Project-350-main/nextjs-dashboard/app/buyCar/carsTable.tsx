import { fetchCars, fetchFilteredCars } from '@/app/lib/data';
import clsx from 'clsx';
import CarDetailModal from './popup';

export default async function CarsTable({
  queryMax,
  queryMiles,
  queryBrand,
  currentPage,
  searchQuery,
  queryFuel,
}: {
  queryMax: string;
  queryMiles: string;
  queryBrand: string;
  currentPage: number;
  searchQuery: string;
  queryFuel: string;
}) {
  
  const filteredCars = await fetchFilteredCars(queryMax, queryMiles,queryBrand, currentPage, searchQuery, queryFuel);
  
  if (!filteredCars || filteredCars.length === 0) {
    return <p>No cars found.</p>;
  }

  return (
    <div className="bg-gray-100 pt-4 relative">
      {filteredCars?.map((car, i) => (
        <div
          key={car.car_id}
          className={clsx('items-center justify-between py-4', {
            'border-t': i !== 0,
          })}
        >
          <button
            className="car-button"
            data-car={JSON.stringify({
              ...car,
              first_name: car.first_name,
              last_name: car.last_name,
            })}
          >
            <div className="flex flex-col sm:flex-row gap-4">
              {/* Larger Image Section */}
              <div className="p-4 bg-white w-full sm:w-2/3">
                {car.image_url ? (
                  <img
                    src={car.image_url}
                    width={800}
                    height={600}
                    alt={`${car.brand_name} ${car.car_model}`}
                    className="w-full h-auto object-cover"
                  />
                ) : (
                  <p>No Image Available</p>
                )}
              </div>

              {/* Smaller Car Details Section */}
              <div className="p-4 bg-white w-full sm:w-1/3 space-y-3 ">
                <p><strong>Brand:</strong> {car.brand_name}</p>
                <p><strong>Model:</strong> {car.car_model}</p>
                <p><strong>Year:</strong> {car.year}</p>
                <p><strong>Mileage:</strong> {car.mileage} miles</p>
                <p><strong>Condition:</strong> {car.condition}/5</p>
                <p><strong>Price:</strong> ${car.price}</p>
                <p><strong>Location:</strong> {car.state_name}</p>
                <p><strong>Fuel type:</strong> {car.fuel_name}</p>
                <p><strong>Exterior color:</strong> {car.exterior_color}</p>
                <p><strong>Interior color:</strong> {car.interior_color}</p>
              </div>
            </div>
          </button>
        </div>
      ))}
      <CarDetailModal />
    </div>
  );
}
