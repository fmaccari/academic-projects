'use client';

import { useEffect, useState } from 'react';

export default function CarDetailModal() {
  const [modalVisible, setModalVisible] = useState(false);
  const [carData, setCarData] = useState<{ first_name?: string; last_name?: string; email?: string }>({});

  useEffect(() => {
    const carButtons = document.querySelectorAll('.car-button');
    carButtons.forEach((button) => {
      button.addEventListener('click', (e) => {
        const carData = JSON.parse((e.currentTarget as HTMLButtonElement).dataset.car || '{}');
        setCarData({
          first_name: carData.first_name,
          last_name: carData.last_name,
          email: carData.email,
        });
        setModalVisible(true); // Show the modal
      });
    });

    return () => {
      carButtons.forEach((button) => {
        button.removeEventListener('click', () => {});
      });
    };
  }, []);

  return (
    modalVisible && (
      <div className="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50">
        <div className="bg-white p-6 rounded-lg w-96">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Car Seller Details</h2>
            <button
              onClick={() => setModalVisible(false)} // Close the modal
              className="text-xl font-bold"
            >
              &times;
            </button>
          </div>
          <div className="mt-4">
            <p>If you are interested please contact the seller, here are the contact info:</p>
          </div>
          <div className="mt-4">
            <p><strong>Seller's Name:</strong> {carData.first_name || 'N/A'} {carData.last_name || 'N/A'}</p>
            <p><strong>Seller's Email:</strong> {carData.email || 'N/A'}</p>
          </div>
          <div className="mt-6 flex justify-end">
            <button
              onClick={() => setModalVisible(false)} // Close the modal
              className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-700"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    )
  );
}
