"use client";

import React, { useState, useEffect } from "react";

export default function CompareCarsPage() {
  const [brands, setBrands] = useState([]);
  const [models1, setModels1] = useState([]);
  const [models2, setModels2] = useState([]);
  const [selectedBrand1, setSelectedBrand1] = useState(null);
  const [selectedBrand2, setSelectedBrand2] = useState(null);
  const [selectedModel1, setSelectedModel1] = useState(null);
  const [selectedModel2, setSelectedModel2] = useState(null);
  const [comparisonCriterion, setComparisonCriterion] = useState("condition");
  const [comparisonResult, setComparisonResult] = useState(null);
  const [sellerInfo, setSellerInfo] = useState(null); 
  const [error, setError] = useState("");


  useEffect(() => {
    async function loadBrands() {
      try {
        const response = await fetch("/api/cars?action=fetchBrands");
        if (!response.ok) throw new Error(`Failed to fetch brands: ${response.statusText}`);
        const data = await response.json();
        setBrands(data);
      } catch (err) {
        console.error("Error loading brands:", err);
        setError("Failed to load car brands.");
      }
    }
    loadBrands();
  }, []);


  useEffect(() => {
    async function loadModels1() {
      if (selectedBrand1) {
        try {
          const response = await fetch(`/api/cars?action=fetchModels&brandId=${selectedBrand1}`);
          if (!response.ok) throw new Error(`Failed to fetch models for Brand 1`);
          const data = await response.json();
          setModels1(data);
        } catch (err) {
          console.error("Error fetching models for Brand 1:", err);
          setError("Failed to fetch car models for the first brand.");
        }
      }
    }
    loadModels1();
  }, [selectedBrand1]);

  
  useEffect(() => {
    async function loadModels2() {
      if (selectedBrand2) {
        try {
          const response = await fetch(`/api/cars?action=fetchModels&brandId=${selectedBrand2}`);
          if (!response.ok) throw new Error(`Failed to fetch models for Brand 2`);
          const data = await response.json();
          setModels2(data);
        } catch (err) {
          console.error("Error fetching models for Brand 2:", err);
          setError("Failed to fetch car models for the second brand.");
        }
      }
    }
    loadModels2();
  }, [selectedBrand2]);

  async function handleCompare() {
    if (selectedModel1 && selectedModel2) {
     
        const response1 = await fetch(`/api/cars?action=fetchCar&modelId=${selectedModel1}`);
        const car1 = await response1.json();

        const response2 = await fetch(`/api/cars?action=fetchCar&modelId=${selectedModel2}`);
        const car2 = await response2.json();
  
      let betterCar;
      let isTie = false;
      let message = "";
  
      
      if (comparisonCriterion === "condition") {
        if (car1.condition > car2.condition) {
          betterCar = { car: car1, comparison: "better by condition" };
          message = ""; 
        } else if (car1.condition < car2.condition) {
          betterCar = { car: car2, comparison: "better by condition" };
          message = ""; 
        } else {
         
          isTie = true;
          if (car1.mileage < car2.mileage) {
            betterCar = { car: car1, comparison: "better by mileage" };
            message = "It's a tie in condition, but the car with better mileage is shown.";
          } else if (car1.mileage > car2.mileage) {
            betterCar = { car: car2, comparison: "better by mileage" };
            message = "It's a tie in condition, but the car with better mileage is shown.";
          } else {
            
            if (car1.price < car2.price) {
              betterCar = { car: car1, comparison: "better by price" };
              message = "It's a tie in condition and mileage, but the car with a better price is shown.";
            } else if (car1.price > car2.price) {
              betterCar = { car: car2, comparison: "better by price" };
              message = "It's a tie in condition and mileage, but the car with a better price is shown.";
            } else {
            
              betterCar = { car: car1, comparison: "better by default" };
              message = "It's a complete tie in condition, mileage, and price. Displaying the first car by default.";
            }
          }
        }
      } else if (comparisonCriterion === "mileage") {
        if (car1.mileage < car2.mileage) {
          betterCar = { car: car1, comparison: "better by mileage" };
          message = ""; 
        } else if (car1.mileage > car2.mileage) {
          betterCar = { car: car2, comparison: "better by mileage" };
          message = ""; 
        } else {
          
          isTie = true;
          if (car1.price < car2.price) {
            betterCar = { car: car1, comparison: "better by price" };
            message = "It's a tie in mileage, but the car with a better price is shown.";
          } else if (car1.price > car2.price) {
            betterCar = { car: car2, comparison: "better by price" };
            message = "It's a tie in mileage, but the car with a better price is shown.";
          } else {
            
            betterCar = { car: car1, comparison: "better by default" };
            message = "It's a complete tie in mileage and price. Displaying the first car by default.";
          }
        }
      } else if (comparisonCriterion === "price") {
        if (car1.price < car2.price) {
          betterCar = { car: car1, comparison: "better by price" };
          message = ""; 
        } else if (car1.price > car2.price) {
          betterCar = { car: car2, comparison: "better by price" };
          message = ""; 
        } else {
          
          isTie = true;
          if (car1.mileage < car2.mileage) {
            betterCar = { car: car1, comparison: "better by mileage" };
            message = "It's a tie in price, but the car with better mileage is shown.";
          } else if (car1.mileage > car2.mileage) {
            betterCar = { car: car2, comparison: "better by mileage" };
            message = "It's a tie in price, but the car with better mileage is shown.";
          } else {
            
            betterCar = { car: car1, comparison: "better by default" };
            message = "It's a complete tie in price and mileage. Displaying the first car by default.";
          }
        }
      }
  
      setComparisonResult({ car1, car2, betterCar, message });
    }
  }
 
  async function fetchSellerInfo(carId) {
    try {
      const response = await fetch(`/api/cars?action=fetchCar&modelId=${carId}`);
      if (!response.ok) throw new Error("Failed to fetch seller information.");
      const data = await response.json();
      setSellerInfo(data);
    } catch (err) {
      console.error("Error fetching seller information:", err);
      setError("Failed to fetch seller information.");
    }
  }

  function handleCarClick(carId) {
    fetchSellerInfo(carId);
  }

  return (
    <div className="flex flex-wrap p-10 font-sans">
      <div className="w-full md:w-1/2">
        <h1 className="text-3xl font-bold mb-6">Compare Cars</h1>
        <div className="mb-6">
          <label className="block mb-2 text-lg font-semibold">
            Select Comparison Criterion:
          </label>
          <select
            className="mt-1 block w-full border rounded-lg p-2"
            value={comparisonCriterion}
            onChange={(e) => setComparisonCriterion(e.target.value)}
          >
            <option value="condition">Condition</option>
            <option value="mileage">Mileage</option>
            <option value="price">Price</option>
          </select>
        </div>

        <div className="mb-6">
          <h2 className="text-xl font-semibold mb-4">First Car</h2>
          <label className="block mb-2">
            Select Brand:
            <select
              className="mt-1 block w-full border rounded-lg p-2"
              value={selectedBrand1 || ""}
              onChange={(e) => {
                setSelectedBrand1(e.target.value);
                setModels1([]);
                setSelectedModel1(null);
                setComparisonResult(null);
              }}
            >
              <option value="">-- Select a Brand --</option>
              {brands.map((b) => (
                <option key={b.brand_id} value={b.brand_id}>
                  {b.brand_name}
                </option>
              ))}
            </select>
          </label>
          {models1.length > 0 && (
            <label className="block mt-4">
              Select Model:
              <select
                className="mt-1 block w-full border rounded-lg p-2"
                value={selectedModel1 || ""}
                onChange={(e) => {
                  setSelectedModel1(e.target.value);
                  setComparisonResult(null);
                }}
              >
                <option value="">-- Select a Model --</option>
                {models1.map((m) => (
                  <option key={m.car_id} value={m.car_id}>
                    {m.car_model}
                  </option>
                ))}
              </select>
            </label>
          )}
        </div>

        <div className="mb-6">
          <h2 className="text-xl font-semibold mb-4">Second Car</h2>
          <label className="block mb-2">
            Select Brand:
            <select
              className="mt-1 block w-full border rounded-lg p-2"
              value={selectedBrand2 || ""}
              onChange={(e) => {
                setSelectedBrand2(e.target.value);
                setModels2([]);
                setSelectedModel2(null);
                setComparisonResult(null);
              }}
            >
              <option value="">-- Select a Brand --</option>
              {brands.map((b) => (
                <option key={b.brand_id} value={b.brand_id}>
                  {b.brand_name}
                </option>
              ))}
            </select>
          </label>
          {models2.length > 0 && (
            <label className="block mt-4">
              Select Model:
              <select
                className="mt-1 block w-full border rounded-lg p-2"
                value={selectedModel2 || ""}
                onChange={(e) => {
                  setSelectedModel2(e.target.value);
                  setComparisonResult(null);
                }}
              >
                <option value="">-- Select a Model --</option>
                {models2.map((m) => (
                  <option key={m.car_id} value={m.car_id}>
                    {m.car_model}
                  </option>
                ))}
              </select>
            </label>
          )}
        </div>

        <button
          className="bg-blue-500 text-white py-2 px-4 rounded-lg mt-4 hover:bg-blue-600 disabled:bg-gray-300"
          onClick={handleCompare}
          disabled={!selectedModel1 || !selectedModel2}
        >
          Compare Cars
        </button>
      </div>

      <div className="w-full md:w-1/2 p-10 pt-1">
        {comparisonResult && (
          <div>
            <h2 className="text-2xl font-bold mb-4">We found the best match for you!</h2>
            {comparisonResult.message && (
              <p className="text-lg text-yellow-600">{comparisonResult.message}</p>
            )}
            {comparisonResult.betterCar && (
              <div className="mt-6">
                <p className="text-lg font-semibold">
                  Our best car for you is{" "}
                  <span className="text-blue-500">
                    {comparisonResult.betterCar.car.car_model}
                  </span>
                </p>
                <img
                  className="mt-4 rounded-lg border shadow-md max-w-full cursor-pointer hover:opacity-80"
                  src={comparisonResult.betterCar.car.image_url}
                  alt={comparisonResult.betterCar.car.car_model}
                  onClick={() => handleCarClick(comparisonResult.betterCar.car.car_id)}
                />
              </div>
            )}
          </div>
        )}
      </div>

      {sellerInfo && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
          <div className="bg-white rounded-lg p-6 shadow-lg">
            <h2 className="text-2xl font-bold mb-4">Seller Information</h2>
            <p className="mb-2">
              <strong>Name:</strong> {sellerInfo.seller_name}
            </p>
            <p className="mb-2">
              <strong>Email:</strong> {sellerInfo.seller_email}
            </p>
            <p className="mb-2">
              <strong>State:</strong> {sellerInfo.state_name}
            </p>
            <button
              className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
              onClick={() => setSellerInfo(null)}
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
