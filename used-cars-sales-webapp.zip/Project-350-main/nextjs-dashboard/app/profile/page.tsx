"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { upload } from "@vercel/blob/client";

export default function ProfilePage() {
  const [profile, setProfile] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  const fetchProfile = async () => {
    const sellerId = localStorage.getItem("seller_id");
    console.log("Seller ID from localStorage:", sellerId);

    if (!sellerId) {
      setProfile(null);
      setLoading(false);
      //router.push("/login");
      return;
    }

    try {
      const response = await fetch(`http://127.0.0.1:5000/profile?seller_id=${sellerId}`);
      const data = await response.json();
      console.log("Profile data:", data);
      if (response.ok) {
        setProfile(data);
      } else if (response.status === 401) {
        setProfile(null);
        router.push("/profile");
      }
      setLoading(false);
    } catch (err) {
      setError("Error fetching profile. Please check your connection.");
      setLoading(false);
    }
  };

  const logout = async () => {
    try {
      const sellerId = localStorage.getItem("seller_id");
      if (!sellerId) {
        alert("No user is logged in.");
        router.push("/profile");
        return;
      }

      const response = await fetch("http://127.0.0.1:5000/logout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ seller_id: sellerId }),
      });

      if (response.ok) {
        alert("Logged out successfully!");
        localStorage.removeItem("seller_id");
        setProfile(null);
        router.push("/profile");
      } else {
        const errorData = await response.json();
        alert(errorData.error || "Failed to log out.");
      }
    } catch (err) {
      alert("Error logging out. Please check your connection.");
    }
  };

  const launchCarForm = async () => {
    try {
      const sellerId = localStorage.getItem("seller_id");
      const response = await fetch("http://127.0.0.1:5000/launch-car-form", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ seller_id: sellerId }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        setError(errorData.error || "Failed to launch car form.");
      } else {
        alert("Car form launched! Please complete the submission.");
        setTimeout(fetchProfile, 5000);
      }
    } catch (err) {
      setError("Error launching car form. Please check your connection.");
    }
  };

  const launchEditCarForm = async (carId) => {
    try {
      const sellerId = localStorage.getItem("seller_id");
      const response = await fetch("http://127.0.0.1:5000/launch-edit-car", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ car_id: carId, seller_id: sellerId }),
      });
      if (response.ok) {
        alert("Edit car form launched! Please complete the changes.");
      } else {
        const errorData = await response.json();
        alert(errorData.error || "Failed to launch edit car form.");
      }
    } catch (err) {
      alert("Error launching edit car form. Please check your connection.");
    }
  };

  const removeCar = async (carId) => {
    try {
      const sellerId = localStorage.getItem("seller_id"); 
      if (!sellerId) {
        alert("Seller is not logged in.");
        return;
      }
  
      const response = await fetch("http://127.0.0.1:5000/remove-car", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ car_id: carId, seller_id: sellerId }), 
      });
  
      if (response.ok) {
        alert("Car removed successfully!");
        fetchProfile(); 
      } else {
        const errorData = await response.json();
        alert(errorData.error || "Failed to remove car.");
      }
    } catch (err) {
      console.error("Error removing car:", err);
      alert("Error removing car. Please check your connection.");
    }
  };
  

  const uploadCarImage = async (carId, file) => {
    try {
      const response = await fetch(`/api/car/upload?filename=${file.name}`, {
        method: "POST",
        body: file,
      });

      if (!response.ok) {
        throw new Error("Failed to upload image.");
      }

      const blob = await response.json();

      const backendResponse = await fetch("http://127.0.0.1:5000/update-car-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ car_id: carId, image_url: blob.url }),
      });

      if (!backendResponse.ok) {
        const errorData = await backendResponse.json();
        throw new Error(errorData.error || "Failed to update car image.");
      }

      alert("Car image uploaded successfully!");
      fetchProfile();
    } catch (err) {
      console.error("Error uploading car image:", err);
      alert("Error uploading car image. Please check your connection.");
    }
  };

  const handleFileChange = (event, carId) => {
    const file = event.target.files[0];
    if (file) {
      uploadCarImage(carId, file);
    }
  };

  useEffect(() => {
    fetchProfile();
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (profile === null) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-r from-gray-100 to-gray-200">
        <div className="flex items-center justify-center bg-white shadow-md rounded-lg overflow-hidden w-4/5 max-w-4xl">
          
          <div className="w-1/2 p-8">
            <h1 className="text-4xl font-bold text-gray-800 mb-6">
              Start Selling !
            </h1>
            <p className="text-lg text-gray-600 mb-8 ">
              To access your account or create one,  click the button below.
            </p>
            <button
              onClick={() => router.push("/login")}
              className="relative group bg-blue-500 text-white px-6 py-3 rounded-lg font-semibold shadow-md hover:bg-blue-600 transition duration-300"
            >
              <span className="absolute inset-0 bg-blue-600 transition-transform transform scale-x-0 group-hover:scale-x-100 group-hover:opacity-50 duration-300 justify-center"></span>
              <span className="relative">Click here!</span>
            </button>
          </div>
    
          
          <div className="w-1/2">
            <img
              src="/logimage.jpg" 
              alt="Login Illustration"
              className="w-full max-h-96 object-contain rounded-lg shadow-lg hover:shadow-2xl hover:scale-105 transform transition duration-300 ease-in-out"
      />
          </div>
        </div>
      </div>
    );
    
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div className="min-h-screen bg-gray-100 py-10">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold text-gray-800 mb-6">Welcome, {profile.user_name}</h1>
        <h2 className="text-xl font-semibold text-gray-700 mb-4">Your Cars:</h2>

        <div className="space-y-4">
          {profile.cars.map((car, index) => (
            <div
              key={index}
              className="bg-white shadow-md rounded-lg overflow-hidden border border-gray-200 flex items-center justify-between p-4"
            >
              <div className="flex items-center space-x-4">
                {car[11] && (
                  <img
                    src={car[11]}
                    alt="Car Image"
                    className="w-32 h-32 object-cover rounded-lg"
                  />
                )}
                <div>
                  <h3 className="text-lg font-semibold text-gray-800">
                    {car[1]} - {car[2]}
                  </h3>
                  <p className="text-sm text-gray-600">
                    <strong>Mileage:</strong> {car[3]} miles
                  </p>
                  <p className="text-sm text-gray-600">
                    <strong>Year:</strong> {car[4]}
                  </p>
                  <p className="text-sm text-gray-600">
                    <strong>Condition:</strong> {car[5]}
                  </p>
                  <p className="text-sm text-gray-600">
                    <strong>Price:</strong> ${car[6]}
                  </p>
                  <p className="text-sm text-gray-600">
                    <strong>State:</strong> {car[7]}
                  </p>
                  <p className="text-sm text-gray-600">
                    <strong>Fuel Type:</strong> {car[8]}
                  </p>
                  <p className="text-sm text-gray-600">
                    <strong>Exterior Color:</strong> {car[9]}
                  </p>
                  <p className="text-sm text-gray-600">
                    <strong>Interior Color:</strong> {car[10]}
                  </p>
                </div>
              </div>

              <div className="flex flex-col items-center space-y-2">
                <input
                  type="file"
                  accept="image/*"
                  onChange={(event) => handleFileChange(event, car[0])}
                  className="text-sm text-gray-500"
                />
                <button
                  onClick={() => launchEditCarForm(car[0])}
                  className="bg-blue-500 text-white text-sm px-4 py-2 rounded shadow hover:bg-blue-600"
                >
                  Edit
                </button>
                <button
                  onClick={() => removeCar(car[0])}
                  className="bg-red-500 text-white text-sm px-4 py-2 rounded shadow hover:bg-red-600"
                >
                  Remove
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-10 flex space-x-4">
          <button
            onClick={launchCarForm}
            className="bg-green-500 text-white px-6 py-3 rounded shadow hover:bg-green-600"
          >
            Add a New Car
          </button>
          <button
            onClick={fetchProfile}
            className="bg-yellow-500 text-white px-6 py-3 rounded shadow hover:bg-yellow-600"
          >
            Refresh
          </button>
          <button
            onClick={logout}
            className="bg-red-500 text-white px-6 py-3 rounded shadow hover:bg-red-600"
          >
            Log Out
          </button>
        </div>
      </div>
    </div>
  );
}
