import Nav from './ui/dashboard/sidenav';
import NavLinks from './ui/dashboard/nav-links';
import '@/app/ui/global.css';
export const experimental_ppr=true;

export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <html>
     <body>
      
    
    <div className="divide-y divide-slate-100 bg-transparent min-h-screen">
      <div className='bg-blue-950'>

      <Nav >
        <NavLinks />
      </Nav>
      </div>
      <main>{children}</main>
    </div>
     </body> 
    </html>
  );
}