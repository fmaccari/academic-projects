import { NextRequest, NextResponse } from "next/server";
import { fetchCarBrandsCompare, fetchCarModels, fetchBestConditionCar } from "@/app/lib/data";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const action = searchParams.get("action");
    const brandId = searchParams.get("brandId");
    const modelId = searchParams.get("modelId");

    if (action === "fetchBrands") {
      const brands = await fetchCarBrandsCompare();
      return NextResponse.json(brands);
    }

    if (action === "fetchModels" && brandId) {
      const models = await fetchCarModels(brandId);
      return NextResponse.json(models);
    }

    if (action === "fetchCar" && modelId) {
      const car = await fetchBestConditionCar(modelId);
      return NextResponse.json(car);
    }

    return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  } catch (error) {
    console.error("API Error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
