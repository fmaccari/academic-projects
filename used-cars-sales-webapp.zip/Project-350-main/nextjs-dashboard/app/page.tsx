import Link from 'next/link';
import { Button } from './ui/button';
import Search from './ui/search';
import { PowerIcon, UserIcon } from '@heroicons/react/24/outline';

export default function Page() { 
    return ( 
        <main className="relative flex min-h-screen flex-col p-6 justify-between">

      <div
    className="absolute inset-0 bg-cover bg-center opacity-30"
    style={{ backgroundImage: "url('/desertroad.jpg')" }}
      ></div>
     <div className="absolute inset-0 bg-black opacity-40"></div>

  
  <div className="absolute top-10 left-10 w-40 h-40 bg-indigo-400 rounded-full blur-2xl opacity-30"></div>
  <div className="absolute bottom-20 right-20 w-60 h-60 bg-blue-300 rounded-full blur-3xl opacity-30"></div>
  <div className="absolute top-1/3 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-purple-500 rounded-full blur-3xl opacity-20"></div>

  
  <div className="relative flex min-h-screen flex-col items-center justify-center gap-10 px-6 py-10 md:w-5/5 md:px-40 z-10">
   
    <div className="text-center">
      <h1 className="text-4xl font-bold text-white mb-4 drop-shadow-lg shadow-black">
        Discover Your Next Adventure
      </h1>
      <p className="text-lg text-gray-200 italic">
        Search for your next car
      </p>
    </div>

    
    <Search placeholder="Search for a state to buy in... car brand... car type... car color..."></Search>

    <div className="flex flex-row items-center justify-center gap-10">
      <Link href="/profile">
        <Button className="px-6 py-3 bg-blue-500 text-white rounded-lg shadow-md hover:bg-blue-600 transition">
          Sell a Car
        </Button>
      </Link>
      <Link href="/buyCar">
        <Button className="px-6 py-3 bg-green-500 text-white rounded-lg shadow-md hover:bg-green-600 transition">
          Buy a Car
        </Button>
      </Link>
    </div>
  </div>
</main>

      
    ); 
}