import { sql } from '@vercel/postgres';

import {
  CarField,
  cars,
  sellers,
  brands,
  colors,
  states,
  fuels
} from './definitions';
import { formatCurrency } from './utils';
import NotFound from '../buyCar/[id]/not-found';

export async function fetchCars() {
  try {
    console.log('Fetching cars data...');
     //await new Promise((resolve) => setTimeout(resolve, 3000));
    
     const data = await sql<cars>
     `SELECT cars.car_id, brands.brand_name, cars.car_model, cars.year, cars.milage, cars.condition, cars.price, states.state_name,
      fuels.fuel_name, exterior_colors.color_name AS exterior_color, interior_colors.color_name AS interior_color, sellers.email
      FROM cars
      JOIN sellers on cars.car_id=sellers.seller_id
      JOIN brands on cars.brand_id=brands.brand_id
      JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
      JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
      JOIN states on cars.state_id=states.state_id
      JOIN fuels on cars.fuel_id=fuels.fuel_id `;

    /*const cars = data.rows.map((car) => ({
      ...car,
    }));*/
    return data.rows;
  } catch (error) {
    console.error('Database Error:', error);
    throw new Error('Failed to fetch the cars.');
  }
}


const ITEMS_PER_PAGE = 4;
export async function fetchFilteredCars(
  queryMax: string,
  queryMiles: string,
  queryBrand: string,
  currentPage: number,
  searchQuery: string,
  queryFuel: string,
) {
  const offset = (currentPage - 1) * ITEMS_PER_PAGE;
  const maxPrice = queryMax === '' || isNaN(Number(queryMax)) ? null : Number(queryMax);
  const maxMiles = queryMiles === '' || isNaN(Number(queryMiles)) ? null : Number(queryMiles);
  const brand = queryBrand ? queryBrand : null;
  const fuel = queryFuel ? queryFuel : null;

  if (searchQuery !== '') {
    try {
      console.log('Fetching cars with searchQuery:', searchQuery);
      const data = await sql<cars>`
        SELECT cars.car_id, cars.image_url, brands.brand_name, cars.car_model, cars.year, cars.mileage, cars.condition, cars.price, 
               states.state_name, fuels.fuel_name, exterior_colors.color_name AS exterior_color, 
               interior_colors.color_name AS interior_color, sellers.email, sellers.first_name, sellers.last_name
        FROM cars
        JOIN sellers ON cars.seller_id = sellers.id
        JOIN brands ON cars.brand_id = brands.brand_id
        JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
        JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
        JOIN states ON cars.state_id = states.state_id
        JOIN fuels ON cars.fuel_id = fuels.fuel_id
        WHERE brands.brand_name ILIKE ${searchQuery} OR
              cars.car_model ILIKE ${searchQuery} OR
              exterior_colors.color_name ILIKE ${searchQuery} OR
              states.state_name ILIKE ${searchQuery}
        ORDER BY cars.price ASC
        LIMIT ${ITEMS_PER_PAGE} OFFSET ${offset}
      `;
      return data.rows;
    } catch (error) {
      console.error('Database Error in search query:', error);
      throw new Error('Failed to fetch searched cars.');
    }
  }
  try {
    if (maxPrice !== null && brand !== null && fuel !== null && maxMiles!==null) {
      const data = await sql<cars>`
        SELECT cars.car_id, cars.image_url, brands.brand_name, cars.car_model, cars.year, cars.mileage, cars.condition, cars.price, 
               states.state_name, fuels.fuel_name, exterior_colors.color_name AS exterior_color, 
               interior_colors.color_name AS interior_color, sellers.email, sellers.first_name, sellers.last_name
        FROM cars
        JOIN sellers ON cars.seller_id = sellers.id
        JOIN brands ON cars.brand_id = brands.brand_id
        JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
        JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
        JOIN states ON cars.state_id = states.state_id
        JOIN fuels ON cars.fuel_id = fuels.fuel_id
        WHERE cars.price <= ${maxPrice} AND brands.brand_name ILIKE ${`%${brand}%`} AND fuels.fuel_name ILIKE ${`%${fuel}%`} AND cars.mileage <= ${maxMiles}
        ORDER BY cars.price ASC
        LIMIT ${ITEMS_PER_PAGE} OFFSET ${offset}
      `;
      return data.rows;
    }
    if (maxPrice !== null && brand !== null && fuel !== null && maxMiles===null) {
      const data = await sql<cars>`
        SELECT cars.car_id, cars.image_url, brands.brand_name, cars.car_model, cars.year, cars.mileage, cars.condition, cars.price, 
               states.state_name, fuels.fuel_name, exterior_colors.color_name AS exterior_color, 
               interior_colors.color_name AS interior_color, sellers.email, sellers.first_name, sellers.last_name
        FROM cars
        JOIN sellers ON cars.seller_id = sellers.id
        JOIN brands ON cars.brand_id = brands.brand_id
        JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
        JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
        JOIN states ON cars.state_id = states.state_id
        JOIN fuels ON cars.fuel_id = fuels.fuel_id
        WHERE cars.price <= ${maxPrice} AND brands.brand_name ILIKE ${`%${brand}%`} AND fuels.fuel_name ILIKE ${`%${fuel}%`}
        ORDER BY cars.price ASC
        LIMIT ${ITEMS_PER_PAGE} OFFSET ${offset}
      `;
      return data.rows;
    }
    if (maxPrice !== null && brand !== null && fuel === null && maxMiles!==null) {
      const data = await sql<cars>`
        SELECT cars.car_id, cars.image_url, brands.brand_name, cars.car_model, cars.year, cars.mileage, cars.condition, cars.price, 
               states.state_name, fuels.fuel_name, exterior_colors.color_name AS exterior_color, 
               interior_colors.color_name AS interior_color, sellers.email, sellers.first_name, sellers.last_name
        FROM cars
        JOIN sellers ON cars.seller_id = sellers.id
        JOIN brands ON cars.brand_id = brands.brand_id
        JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
        JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
        JOIN states ON cars.state_id = states.state_id
        JOIN fuels ON cars.fuel_id = fuels.fuel_id
        WHERE cars.price <= ${maxPrice} AND brands.brand_name ILIKE ${`%${brand}%`} AND cars.mileage <= ${maxMiles}
        ORDER BY cars.price ASC
        LIMIT ${ITEMS_PER_PAGE} OFFSET ${offset}
      `;
      return data.rows;
    }
    if (maxPrice !== null && brand !== null && fuel === null && maxMiles===null) {
      const data = await sql<cars>`
        SELECT cars.car_id, cars.image_url, brands.brand_name, cars.car_model, cars.year, cars.mileage, cars.condition, cars.price, 
               states.state_name, fuels.fuel_name, exterior_colors.color_name AS exterior_color, 
               interior_colors.color_name AS interior_color, sellers.email, sellers.first_name, sellers.last_name
        FROM cars
        JOIN sellers ON cars.seller_id = sellers.id
        JOIN brands ON cars.brand_id = brands.brand_id
        JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
        JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
        JOIN states ON cars.state_id = states.state_id
        JOIN fuels ON cars.fuel_id = fuels.fuel_id
        WHERE cars.price <= ${maxPrice} AND brands.brand_name ILIKE ${`%${brand}%`}
        ORDER BY cars.price ASC
        LIMIT ${ITEMS_PER_PAGE} OFFSET ${offset}
      `;
      return data.rows;
    }
    if (maxPrice !== null && brand === null && fuel !== null && maxMiles!==null) {
      const data = await sql<cars>`
        SELECT cars.car_id, cars.image_url, brands.brand_name, cars.car_model, cars.year, cars.mileage, cars.condition, cars.price, 
               states.state_name, fuels.fuel_name, exterior_colors.color_name AS exterior_color, 
               interior_colors.color_name AS interior_color, sellers.email, sellers.first_name, sellers.last_name
        FROM cars
        JOIN sellers ON cars.seller_id = sellers.id
        JOIN brands ON cars.brand_id = brands.brand_id
        JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
        JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
        JOIN states ON cars.state_id = states.state_id
        JOIN fuels ON cars.fuel_id = fuels.fuel_id
        WHERE cars.price <= ${maxPrice} AND fuels.fuel_name ILIKE ${`%${fuel}%`} AND cars.mileage <= ${maxMiles}
        ORDER BY cars.price ASC
        LIMIT ${ITEMS_PER_PAGE} OFFSET ${offset}
      `;
      return data.rows;
    }
    if (maxPrice !== null && brand === null && fuel !== null && maxMiles===null) {
      const data = await sql<cars>`
        SELECT cars.car_id, cars.image_url, brands.brand_name, cars.car_model, cars.year, cars.mileage, cars.condition, cars.price, 
               states.state_name, fuels.fuel_name, exterior_colors.color_name AS exterior_color, 
               interior_colors.color_name AS interior_color, sellers.email, sellers.first_name, sellers.last_name
        FROM cars
        JOIN sellers ON cars.seller_id = sellers.id
        JOIN brands ON cars.brand_id = brands.brand_id
        JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
        JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
        JOIN states ON cars.state_id = states.state_id
        JOIN fuels ON cars.fuel_id = fuels.fuel_id
        WHERE cars.price <= ${maxPrice} AND fuels.fuel_name ILIKE ${`%${fuel}%`}
        ORDER BY cars.price ASC
        LIMIT ${ITEMS_PER_PAGE} OFFSET ${offset}
      `;
      return data.rows;
    }
    if (maxPrice !== null && brand === null && fuel === null && maxMiles!==null) {
      const data = await sql<cars>`
        SELECT cars.car_id, cars.image_url, brands.brand_name, cars.car_model, cars.year, cars.mileage, cars.condition, cars.price, 
               states.state_name, fuels.fuel_name, exterior_colors.color_name AS exterior_color, 
               interior_colors.color_name AS interior_color, sellers.email, sellers.first_name, sellers.last_name
        FROM cars
        JOIN sellers ON cars.seller_id = sellers.id
        JOIN brands ON cars.brand_id = brands.brand_id
        JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
        JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
        JOIN states ON cars.state_id = states.state_id
        JOIN fuels ON cars.fuel_id = fuels.fuel_id
        WHERE cars.price <= ${maxPrice} AND cars.mileage <= ${maxMiles}
        ORDER BY cars.price ASC
        LIMIT ${ITEMS_PER_PAGE} OFFSET ${offset}
      `;
      return data.rows;
    }
    if (maxPrice !== null && brand === null && fuel === null && maxMiles===null) {
      const data = await sql<cars>`
        SELECT cars.car_id, cars.image_url, brands.brand_name, cars.car_model, cars.year, cars.mileage, cars.condition, cars.price, 
               states.state_name, fuels.fuel_name, exterior_colors.color_name AS exterior_color, 
               interior_colors.color_name AS interior_color, sellers.email, sellers.first_name, sellers.last_name
        FROM cars
        JOIN sellers ON cars.seller_id = sellers.id
        JOIN brands ON cars.brand_id = brands.brand_id
        JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
        JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
        JOIN states ON cars.state_id = states.state_id
        JOIN fuels ON cars.fuel_id = fuels.fuel_id
        WHERE cars.price <= ${maxPrice}
        ORDER BY cars.price ASC
        LIMIT ${ITEMS_PER_PAGE} OFFSET ${offset}
      `;
      return data.rows;
    }
    if (maxPrice === null && brand !== null && fuel !== null && maxMiles!==null) {
      const data = await sql<cars>`
        SELECT cars.car_id, cars.image_url, brands.brand_name, cars.car_model, cars.year, cars.mileage, cars.condition, cars.price, 
               states.state_name, fuels.fuel_name, exterior_colors.color_name AS exterior_color, 
               interior_colors.color_name AS interior_color, sellers.email, sellers.first_name, sellers.last_name
        FROM cars
        JOIN sellers ON cars.seller_id = sellers.id
        JOIN brands ON cars.brand_id = brands.brand_id
        JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
        JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
        JOIN states ON cars.state_id = states.state_id
        JOIN fuels ON cars.fuel_id = fuels.fuel_id
        WHERE brands.brand_name ILIKE ${`%${brand}%`} AND fuels.fuel_name ILIKE ${`%${fuel}%`} AND cars.mileage <= ${maxMiles}
        ORDER BY cars.price ASC
        LIMIT ${ITEMS_PER_PAGE} OFFSET ${offset}
      `;
      return data.rows;
    }
    if (maxPrice === null && brand !== null && fuel !== null && maxMiles===null) {
      const data = await sql<cars>`
        SELECT cars.car_id, cars.image_url, brands.brand_name, cars.car_model, cars.year, cars.mileage, cars.condition, cars.price, 
               states.state_name, fuels.fuel_name, exterior_colors.color_name AS exterior_color, 
               interior_colors.color_name AS interior_color, sellers.email, sellers.first_name, sellers.last_name
        FROM cars
        JOIN sellers ON cars.seller_id = sellers.id
        JOIN brands ON cars.brand_id = brands.brand_id
        JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
        JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
        JOIN states ON cars.state_id = states.state_id
        JOIN fuels ON cars.fuel_id = fuels.fuel_id
        WHERE brands.brand_name ILIKE ${`%${brand}%`} AND fuels.fuel_name ILIKE ${`%${fuel}%`}
        ORDER BY cars.price ASC
        LIMIT ${ITEMS_PER_PAGE} OFFSET ${offset}
      `;
      return data.rows;
    }
    if (maxPrice === null && brand !== null && fuel === null && maxMiles!==null) {
      const data = await sql<cars>`
        SELECT cars.car_id, cars.image_url, brands.brand_name, cars.car_model, cars.year, cars.mileage, cars.condition, cars.price, 
               states.state_name, fuels.fuel_name, exterior_colors.color_name AS exterior_color, 
               interior_colors.color_name AS interior_color, sellers.email, sellers.first_name, sellers.last_name
        FROM cars
        JOIN sellers ON cars.seller_id = sellers.id
        JOIN brands ON cars.brand_id = brands.brand_id
        JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
        JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
        JOIN states ON cars.state_id = states.state_id
        JOIN fuels ON cars.fuel_id = fuels.fuel_id
        WHERE  brands.brand_name ILIKE ${`%${brand}%`} AND cars.mileage <= ${maxMiles}
        ORDER BY cars.price ASC
        LIMIT ${ITEMS_PER_PAGE} OFFSET ${offset}
      `;
      return data.rows;
    }
    if (maxPrice === null && brand !== null && fuel === null && maxMiles===null) {
      const data = await sql<cars>`
        SELECT cars.car_id, cars.image_url, brands.brand_name, cars.car_model, cars.year, cars.mileage, cars.condition, cars.price, 
               states.state_name, fuels.fuel_name, exterior_colors.color_name AS exterior_color, 
               interior_colors.color_name AS interior_color, sellers.email, sellers.first_name, sellers.last_name
        FROM cars
        JOIN sellers ON cars.seller_id = sellers.id
        JOIN brands ON cars.brand_id = brands.brand_id
        JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
        JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
        JOIN states ON cars.state_id = states.state_id
        JOIN fuels ON cars.fuel_id = fuels.fuel_id
        WHERE  brands.brand_name ILIKE ${`%${brand}%`} 
        ORDER BY cars.price ASC
        LIMIT ${ITEMS_PER_PAGE} OFFSET ${offset}
      `;
      return data.rows;
    }
    if (maxPrice === null && brand === null && fuel !== null && maxMiles!==null) {
      const data = await sql<cars>`
        SELECT cars.car_id, cars.image_url, brands.brand_name, cars.car_model, cars.year, cars.mileage, cars.condition, cars.price, 
               states.state_name, fuels.fuel_name, exterior_colors.color_name AS exterior_color, 
               interior_colors.color_name AS interior_color, sellers.email, sellers.first_name, sellers.last_name
        FROM cars
        JOIN sellers ON cars.seller_id = sellers.id
        JOIN brands ON cars.brand_id = brands.brand_id
        JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
        JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
        JOIN states ON cars.state_id = states.state_id
        JOIN fuels ON cars.fuel_id = fuels.fuel_id
        WHERE fuels.fuel_name ILIKE ${`%${fuel}%`} AND cars.mileage <= ${maxMiles}
        ORDER BY cars.price ASC
        LIMIT ${ITEMS_PER_PAGE} OFFSET ${offset}
      `;
      return data.rows;
    }
    if (maxPrice === null && brand === null && fuel !== null && maxMiles===null) {
      const data = await sql<cars>`
        SELECT cars.car_id, cars.image_url, brands.brand_name, cars.car_model, cars.year, cars.mileage, cars.condition, cars.price, 
               states.state_name, fuels.fuel_name, exterior_colors.color_name AS exterior_color, 
               interior_colors.color_name AS interior_color, sellers.email, sellers.first_name, sellers.last_name
        FROM cars
        JOIN sellers ON cars.seller_id = sellers.id
        JOIN brands ON cars.brand_id = brands.brand_id
        JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
        JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
        JOIN states ON cars.state_id = states.state_id
        JOIN fuels ON cars.fuel_id = fuels.fuel_id
        WHERE  fuels.fuel_name ILIKE ${`%${fuel}%`}
        ORDER BY cars.price ASC
        LIMIT ${ITEMS_PER_PAGE} OFFSET ${offset}
      `;
      return data.rows;
    }
    if (maxPrice === null && brand === null && fuel === null && maxMiles!==null) {
      const data = await sql<cars>`
        SELECT cars.car_id, cars.image_url, brands.brand_name, cars.car_model, cars.year, cars.mileage, cars.condition, cars.price, 
               states.state_name, fuels.fuel_name, exterior_colors.color_name AS exterior_color, 
               interior_colors.color_name AS interior_color, sellers.email, sellers.first_name, sellers.last_name
        FROM cars
        JOIN sellers ON cars.seller_id = sellers.id
        JOIN brands ON cars.brand_id = brands.brand_id
        JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
        JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
        JOIN states ON cars.state_id = states.state_id
        JOIN fuels ON cars.fuel_id = fuels.fuel_id
        WHERE cars.mileage <= ${maxMiles}
        ORDER BY cars.price ASC
        LIMIT ${ITEMS_PER_PAGE} OFFSET ${offset}
      `;
      return data.rows;
    }
    if (maxPrice === null && brand === null && fuel === null && maxMiles===null) {
      const data = await sql<cars>`
        SELECT cars.car_id, cars.image_url, brands.brand_name, cars.car_model, cars.year, cars.mileage, cars.condition, cars.price, 
               states.state_name, fuels.fuel_name, exterior_colors.color_name AS exterior_color, 
               interior_colors.color_name AS interior_color, sellers.email, sellers.first_name, sellers.last_name
        FROM cars
        JOIN sellers ON cars.seller_id = sellers.id
        JOIN brands ON cars.brand_id = brands.brand_id
        JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
        JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
        JOIN states ON cars.state_id = states.state_id
        JOIN fuels ON cars.fuel_id = fuels.fuel_id
        ORDER BY cars.price ASC
        LIMIT ${ITEMS_PER_PAGE} OFFSET ${offset}
      `;
      return data.rows;
    }
  } catch (error) {
    console.error('Database Error:', error);
    throw new Error('Failed to fetch filtered cars.');
  }
}


/*
*/

//cars.price > parseInt(${queryMin}) AND
  //      cars.price < parseInt(${queryMax})

  export async function fetchCarPages(queryMax: string, queryMiles: string,queryBrand: string, queryFuel: string,) {
    const maxPrice = queryMax === '' || isNaN(Number(queryMax)) ? null : Number(queryMax);
    const maxMiles = queryMax === '' || isNaN(Number(queryMiles)) ? null : Number(queryMiles);
    const brand = queryBrand ? queryBrand : null;
    const fuel = queryFuel ? queryFuel : null;
    try {
      if (maxPrice !== null && brand !== null && fuel !== null && maxMiles!==null) {
        const count = await sql`
          SELECT COUNT(*)
          FROM cars
          JOIN sellers ON cars.seller_id = sellers.id
          JOIN brands ON cars.brand_id = brands.brand_id
          JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
          JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
          JOIN states ON cars.state_id = states.state_id
          JOIN fuels ON cars.fuel_id = fuels.fuel_id
          WHERE cars.price <= ${maxPrice} AND brands.brand_name ILIKE ${`%${brand}%`} AND fuels.fuel_name ILIKE ${`%${fuel}%`} AND cars.mileage <= ${maxMiles}
        `;
        const totalPages = Math.ceil(Number(count.rows[0].count) / ITEMS_PER_PAGE);
        return totalPages;
  
      } else if (maxPrice !== null && brand !== null && fuel !== null && maxMiles===null) {
        const count = await sql`
          SELECT COUNT(*)
          FROM cars
          JOIN sellers ON cars.seller_id = sellers.id
          JOIN brands ON cars.brand_id = brands.brand_id
          JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
          JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
          JOIN states ON cars.state_id = states.state_id
          JOIN fuels ON cars.fuel_id = fuels.fuel_id
          WHERE cars.price <= ${maxPrice} AND brands.brand_name ILIKE ${`%${brand}%`} AND fuels.fuel_name ILIKE ${`%${fuel}%`}
        `;
        const totalPages = Math.ceil(Number(count.rows[0].count) / ITEMS_PER_PAGE);
        return totalPages;
  
      } else if (maxPrice !== null && brand !== null && fuel === null && maxMiles!==null) {
        const count = await sql`
          SELECT COUNT(*)
          FROM cars
          JOIN sellers ON cars.seller_id = sellers.id
          JOIN brands ON cars.brand_id = brands.brand_id
          JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
          JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
          JOIN states ON cars.state_id = states.state_id
          JOIN fuels ON cars.fuel_id = fuels.fuel_id
          WHERE cars.price <= ${maxPrice} AND brands.brand_name ILIKE ${`%${brand}%`} AND cars.mileage <= ${maxMiles}
        `;
        const totalPages = Math.ceil(Number(count.rows[0].count) / ITEMS_PER_PAGE);
        return totalPages;
  
      }else if (maxPrice !== null && brand !== null && fuel === null && maxMiles===null) {
        const count = await sql`
          SELECT COUNT(*)
          FROM cars
          JOIN sellers ON cars.seller_id = sellers.id
          JOIN brands ON cars.brand_id = brands.brand_id
          JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
          JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
          JOIN states ON cars.state_id = states.state_id
          JOIN fuels ON cars.fuel_id = fuels.fuel_id
          WHERE cars.price <= ${maxPrice} AND brands.brand_name ILIKE ${`%${brand}%`}
        `;
        const totalPages = Math.ceil(Number(count.rows[0].count) / ITEMS_PER_PAGE);
        return totalPages;

      }else if (maxPrice !== null && brand === null && fuel !== null && maxMiles!==null) {
        const count = await sql`
          SELECT COUNT(*)
          FROM cars
          JOIN sellers ON cars.seller_id = sellers.id
          JOIN brands ON cars.brand_id = brands.brand_id
          JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
          JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
          JOIN states ON cars.state_id = states.state_id
          JOIN fuels ON cars.fuel_id = fuels.fuel_id
          WHERE cars.price <= ${maxPrice} AND fuels.fuel_name ILIKE ${`%${fuel}%`} AND cars.mileage <= ${maxMiles}
        `;
        const totalPages = Math.ceil(Number(count.rows[0].count) / ITEMS_PER_PAGE);
        return totalPages;

      }else if (maxPrice !== null && brand === null && fuel !== null && maxMiles===null) {
        const count = await sql`
          SELECT COUNT(*)
          FROM cars
          JOIN sellers ON cars.seller_id = sellers.id
          JOIN brands ON cars.brand_id = brands.brand_id
          JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
          JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
          JOIN states ON cars.state_id = states.state_id
          JOIN fuels ON cars.fuel_id = fuels.fuel_id
          WHERE cars.price <= ${maxPrice} AND fuels.fuel_name ILIKE ${`%${fuel}%`}
        `;
        const totalPages = Math.ceil(Number(count.rows[0].count) / ITEMS_PER_PAGE);
        return totalPages;

      }else if (maxPrice !== null && brand === null && fuel === null && maxMiles!==null) {
        const count = await sql`
          SELECT COUNT(*)
          FROM cars
          JOIN sellers ON cars.seller_id = sellers.id
          JOIN brands ON cars.brand_id = brands.brand_id
          JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
          JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
          JOIN states ON cars.state_id = states.state_id
          JOIN fuels ON cars.fuel_id = fuels.fuel_id
          WHERE cars.price <= ${maxPrice} AND cars.mileage <= ${maxMiles}
        `;
        const totalPages = Math.ceil(Number(count.rows[0].count) / ITEMS_PER_PAGE);
        return totalPages;

      }else if (maxPrice !== null && brand === null && fuel === null && maxMiles===null) {
        const count = await sql`
          SELECT COUNT(*)
          FROM cars
          JOIN sellers ON cars.seller_id = sellers.id
          JOIN brands ON cars.brand_id = brands.brand_id
          JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
          JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
          JOIN states ON cars.state_id = states.state_id
          JOIN fuels ON cars.fuel_id = fuels.fuel_id
          WHERE cars.price <= ${maxPrice}
        `;
        const totalPages = Math.ceil(Number(count.rows[0].count) / ITEMS_PER_PAGE);
        return totalPages;
      }else if (maxPrice === null && brand !== null && fuel !== null && maxMiles!==null) {
        const count = await sql`
          SELECT COUNT(*)
          FROM cars
          JOIN sellers ON cars.seller_id = sellers.id
          JOIN brands ON cars.brand_id = brands.brand_id
          JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
          JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
          JOIN states ON cars.state_id = states.state_id
          JOIN fuels ON cars.fuel_id = fuels.fuel_id
          WHERE brands.brand_name ILIKE ${`%${brand}%`} AND fuels.fuel_name ILIKE ${`%${fuel}%`} AND cars.mileage <= ${maxMiles}
        `;
        const totalPages = Math.ceil(Number(count.rows[0].count) / ITEMS_PER_PAGE);
        return totalPages;
      }else if (maxPrice === null && brand !== null && fuel !== null && maxMiles===null) {
        const count = await sql`
          SELECT COUNT(*)
          FROM cars
          JOIN sellers ON cars.seller_id = sellers.id
          JOIN brands ON cars.brand_id = brands.brand_id
          JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
          JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
          JOIN states ON cars.state_id = states.state_id
          JOIN fuels ON cars.fuel_id = fuels.fuel_id
          WHERE brands.brand_name ILIKE ${`%${brand}%`} AND fuels.fuel_name ILIKE ${`%${fuel}%`}
        `;
        const totalPages = Math.ceil(Number(count.rows[0].count) / ITEMS_PER_PAGE);
        return totalPages;
      }else if (maxPrice === null && brand !== null && fuel === null && maxMiles!==null) {
        const count = await sql`
          SELECT COUNT(*)
          FROM cars
          JOIN sellers ON cars.seller_id = sellers.id
          JOIN brands ON cars.brand_id = brands.brand_id
          JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
          JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
          JOIN states ON cars.state_id = states.state_id
          JOIN fuels ON cars.fuel_id = fuels.fuel_id
          WHERE  brands.brand_name ILIKE ${`%${brand}%`} AND cars.mileage <= ${maxMiles}
        `;
        const totalPages = Math.ceil(Number(count.rows[0].count) / ITEMS_PER_PAGE);
        return totalPages;
      }else if (maxPrice === null && brand !== null && fuel === null && maxMiles===null) {
        const count = await sql`
          SELECT COUNT(*)
          FROM cars
          JOIN sellers ON cars.seller_id = sellers.id
          JOIN brands ON cars.brand_id = brands.brand_id
          JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
          JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
          JOIN states ON cars.state_id = states.state_id
          JOIN fuels ON cars.fuel_id = fuels.fuel_id
          WHERE  brands.brand_name ILIKE ${`%${brand}%`}
        `;
        const totalPages = Math.ceil(Number(count.rows[0].count) / ITEMS_PER_PAGE);
        return totalPages;
      }else if (maxPrice === null && brand === null && fuel !== null && maxMiles!==null) {
        const count = await sql`
        SELECT COUNT(*)
        FROM cars
          JOIN sellers ON cars.seller_id = sellers.id
          JOIN brands ON cars.brand_id = brands.brand_id
          JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
          JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
          JOIN states ON cars.state_id = states.state_id
          JOIN fuels ON cars.fuel_id = fuels.fuel_id
          WHERE fuels.fuel_name ILIKE ${`%${fuel}%`} AND cars.mileage <= ${maxMiles}
        `;
        const totalPages = Math.ceil(Number(count.rows[0].count) / ITEMS_PER_PAGE);
        return totalPages;
      }else if (maxPrice === null && brand === null && fuel !== null && maxMiles===null) {
        const count = await sql`
        SELECT COUNT(*)
        FROM cars
          JOIN sellers ON cars.seller_id = sellers.id
          JOIN brands ON cars.brand_id = brands.brand_id
          JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
          JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
          JOIN states ON cars.state_id = states.state_id
          JOIN fuels ON cars.fuel_id = fuels.fuel_id
          WHERE  fuels.fuel_name ILIKE ${`%${fuel}%`}
        `;
        const totalPages = Math.ceil(Number(count.rows[0].count) / ITEMS_PER_PAGE);
        return totalPages;
      }else if (maxPrice === null && brand === null && fuel === null && maxMiles!==null) {
        const count = await sql`
        SELECT COUNT(*)
        FROM cars
          JOIN sellers ON cars.seller_id = sellers.id
          JOIN brands ON cars.brand_id = brands.brand_id
          JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
          JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
          JOIN states ON cars.state_id = states.state_id
          JOIN fuels ON cars.fuel_id = fuels.fuel_id
          WHERE cars.mileage <= ${maxMiles}
        `;
        const totalPages = Math.ceil(Number(count.rows[0].count) / ITEMS_PER_PAGE);
        return totalPages;
      }else {
        const count = await sql`
        SELECT COUNT(*)
        FROM cars
          JOIN sellers ON cars.seller_id = sellers.id
          JOIN brands ON cars.brand_id = brands.brand_id
          JOIN colors AS exterior_colors ON cars.exterior_color = exterior_colors.color_id
          JOIN colors AS interior_colors ON cars.interior_color = interior_colors.color_id
          JOIN states ON cars.state_id = states.state_id
          JOIN fuels ON cars.fuel_id = fuels.fuel_id
        `;
        const totalPages = Math.ceil(Number(count.rows[0].count) / ITEMS_PER_PAGE);
        return totalPages;
      }
    } catch (error) {
      console.error('Database Error:', error);
      throw new Error('Failed to fetch total number of cars.');
    }
  }
  



export async function fetchCarBrands() {
  try {
    const data = await sql<brands>`
      SELECT
        brand_id,
        brand_name
      FROM brands
      ORDER BY brand_name ASC
    `;
    const carBrands = data.rows;
    return carBrands;
    
  } catch (err) {
    console.error('Database Error:', err);
    throw new Error('Failed to fetch all car brands.');
  }
}

export async function fetchCarFuels() {
  try {
    const data = await sql<fuels>`
      SELECT
        fuel_id,
        fuel_name
      FROM fuels
      ORDER BY fuel_name ASC
    `;
    const carFuels = data.rows;
    return carFuels;
    
  } catch (err) {
    console.error('Database Error:', err);
    throw new Error('Failed to fetch all car fuels.');
  }
}

export async function fetchCarBrandsCompare() {
  try {
    const data = await sql<brands>`
      SELECT brand_id, brand_name 
      FROM brands 
      ORDER BY brand_name ASC
    `;
    return data.rows;
  } catch (err) {
    console.error('Database Error:', err);
    throw new Error('Failed to fetch car brands compare.');
  }
}
export async function fetchCarModels(brandId: string) {
  try {
    const data = await sql`
      SELECT DISTINCT ON (car_model)
        car_id, 
        car_model, 
        condition, 
        mileage, 
        price
      FROM cars
      WHERE brand_id = ${brandId}
      ORDER BY car_model, condition DESC, mileage ASC, price ASC;
    `;
    console.log("Fetched car models (best for each model):", data.rows); 
    return data.rows;
  } catch (error) {
    console.error("Error fetching car models:", error);
    throw new Error("Failed to fetch car models.");
  }
}

export async function fetchBestConditionCar(modelId: string) {
  try {
    const data = await sql<cars>`SELECT 
      cars.car_id, 
      cars.car_model, 
      cars.year, 
      cars.mileage, 
      cars.condition, 
      cars.price, 
      brands.brand_name, 
      states.state_name, 
      colors.color_name AS exterior_color, 
      sellers.first_name || ' ' || sellers.last_name AS seller_name, 
      sellers.email AS seller_email,
      cars.image_url
    FROM cars
    JOIN brands ON cars.brand_id = brands.brand_id
    JOIN states ON cars.state_id = states.state_id
    JOIN colors ON cars.exterior_color = colors.color_id
    JOIN sellers ON cars.seller_id = sellers.id
    WHERE cars.car_id = ${modelId}
    ORDER BY condition DESC, price ASC
    LIMIT 1`;

    console.log("Fetched car:", data.rows[0]); 
    return data.rows[0];
  } catch (err) {
    console.error("Database Error:", err);
    throw new Error("Failed to fetch the best condition car.");
  }
}
