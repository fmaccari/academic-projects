"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const router = useRouter();
  const [error, setError] = useState("");
  const [polling, setPolling] = useState(false);

  const launchLoginForm = async () => {
    try {
      const response = await fetch("http://127.0.0.1:5000/launch-login");
      if (!response.ok) {
        throw new Error("Failed to launch login form.");
      }
      setPolling(true);
      pollLoginStatus();
    } catch (err) {
      setError("Failed to connect to the backend.");
    }
  };
  const pollLoginStatus = async () => {
    try {
      const response = await fetch("http://127.0.0.1:5000/check-login");
      const data = await response.json();
      console.log("Login check response:", data);
  
      if (data.logged_in) {
        console.log("Redirecting to profile");
        localStorage.setItem("seller_id", data.seller_id);
        router.push("/profile");
      } else if (polling) {
        setTimeout(pollLoginStatus, 1000);
      }
    } catch (err) {
      setPolling(false);
      setError("Error checking login status.");
    }
  };
  
  useEffect(() => {
    if (polling) {
      pollLoginStatus();
    }
  }, [polling]);

  if (error) {
    return (
      <div className="flex items-center justify-center h-screen bg-gradient-to-r from-blue-500 to-indigo-600 text-white">
        <div className="bg-white p-6 rounded-lg shadow-md text-black max-w-sm text-center">
          <h1 className="text-2xl font-bold mb-4">Error</h1>
          <p>{error}</p>
        </div>
      </div>
    );
  }

  return (
        <div className="relative min-h-screen bg-gradient-to-r from-blue-500 to-indigo-600 flex items-center justify-center">
  
      <div
        className="absolute inset-0 bg-cover bg-center opacity-25"
        style={{ backgroundImage: "url('/desertroad.jpg')" }}
      ></div>
      <div className="absolute inset-0 bg-black opacity-50"></div>

      <div className="absolute top-10 left-10 w-40 h-40 bg-indigo-400 rounded-full blur-2xl opacity-30"></div>
      <div className="absolute bottom-20 right-20 w-60 h-60 bg-blue-300 rounded-full blur-3xl opacity-30"></div>
      <div className="absolute top-1/3 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-purple-500 rounded-full blur-3xl opacity-20"></div>

      <div className="relative bg-white p-10 rounded-lg shadow-lg max-w-lg w-full z-10">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-800 mb-4">Welcome Back, Seller!</h1>
          <p className="text-gray-600 mb-6">Log in to list your cars and manage your profile.</p>
        </div>
        <div className="text-center">
          <button
            onClick={launchLoginForm}
            className="px-6 py-3 bg-blue-500 text-white text-lg font-semibold rounded-lg shadow-md hover:bg-blue-600 transition"
          >
            Launch Login Form
          </button>
        </div>
        {polling && (
          <div className="mt-4 text-center">
            <p className="text-gray-600 italic">Waiting for login...</p>
          </div>
        )}
      </div>
    </div>

      );
}
